# -*- coding: utf-8 -*-
# run.py – KU_LAHMUMT 대시보드 실행 & 모듈 연동
from __future__ import annotations

import os, sys, subprocess, threading
os.environ["KU_ROLE"] = "decision"
from pathlib import Path
from typing import Dict, List, Tuple, Optional


from PyQt5.QtCore import qInstallMessageHandler, QtMsgType, QObject, pyqtSignal, QTimer
from PyQt5.QtWidgets import QApplication, QTextEdit, QPlainTextEdit


# ─────────────────────────────────────────────────────────────
# Qt 경고 필터 (선택)
def _qt_silent_handler(mode: QtMsgType, context, message: str):
    if "Cannot queue arguments of type" in message:
        return
    if message.startswith("QMainWindowLayout::"):
        return  # 레이아웃 카운트/추가 경고 숨김
    sys.stderr.write(message + "\n")

qInstallMessageHandler(_qt_silent_handler)


# ─────────────────────────────────────────────────────────────
# 경로 부트스트랩
def _bootstrap_paths():
    root = Path(__file__).resolve().parent
    modules_dir = root / "modules"
    common_dir = modules_dir / "common"
    ds_dir = modules_dir / "decision_support"
    for p in (root, modules_dir, common_dir, ds_dir):
        p_str = str(p)
        if p.exists() and p_str not in sys.path:
            sys.path.insert(0, p_str)
    try:
        os.chdir(root)  # CWD 고정(설정/라이선스/어셈블리 검색 안정)
    except Exception:
        pass
    return root, common_dir, ds_dir

PROJECT_ROOT, COMMON_DIR, DS_DIR = _bootstrap_paths()

# ─────────────────────────────────────────────────────────────
# 스타일(QSS) 로드
def _load_qss(app: QApplication):
    candidates = [
        PROJECT_ROOT / "app" / "resources" / "style.qss",
        PROJECT_ROOT / "resources" / "style.qss",
    ]
    for p in candidates:
        if p.exists():
            try:
                app.setStyleSheet(p.read_text(encoding="utf-8"))
                break
            except Exception:
                pass

# ─────────────────────────────────────────────────────────────
# nFusion 설정/라이선스 정규화 + MessageLibrary 로드
def _ensure_fusion_configs():
    # settings
    settings_candidates = [
        PROJECT_ROOT / "nFusionSettings.json",
        DS_DIR / "nFusionSettings.json",
        COMMON_DIR / "nFusionSettings.json",
        PROJECT_ROOT / "FusionSettings.json",
        DS_DIR / "FusionSettings.json",
        COMMON_DIR / "FusionSettings.json",
        PROJECT_ROOT / "nFusion" / "FusionSettings.json",
    ]
    src = next((p for p in settings_candidates if p.exists()), None)
    if src is None:
        sys.stderr.write("WARN: nFusionSettings.json/FusionSettings.json not found; running without bus.\n")
        return None
    dst = PROJECT_ROOT / "nFusionSettings.json"
    if src != dst:
        dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    # license (있으면 루트로 정규화)
    lic_candidates = [
        PROJECT_ROOT / "nFusionLicense.lic",
        DS_DIR / "nFusionLicense.lic",
        COMMON_DIR / "nFusionLicense.lic",
        PROJECT_ROOT / "nFusion" / "nFusionLicense.lic",
    ]
    lic_src = next((p for p in lic_candidates if p.exists()), None)
    if lic_src is not None:
        lic_dst = PROJECT_ROOT / "nFusionLicense.lic"
        if lic_src != lic_dst:
            lic_dst.write_text(lic_src.read_text(encoding="utf-8"), encoding="utf-8")
    return str(dst)

def _load_msglib_and_deps():
    try:
        from dll_files.nFusionImports import clr
    except Exception:
        import clr  # type: ignore
    msg_dir = COMMON_DIR / "msg_files"
    stem = msg_dir / "MessageLibrary"
    try:
        clr.AddReference(str(stem))
    except Exception:
        clr.AddReference(str(stem.with_suffix(".dll")))
    # 의존 DLL(있으면)
    for s in ("K4586Model", "K4586Model.Assist", "MiscUtil"):
        dll = msg_dir / (s + ".dll")
        if dll.exists():
            try:
                clr.AddReference(str(dll.with_suffix("")))
            except Exception:
                try:
                    clr.AddReference(str(dll))
                except Exception:
                    pass

# ─────────────────────────────────────────────────────────────
# 메인 윈도우 로드(경로 가변 지원)
try:
    from app.ui.main_window import MainWindow  # type: ignore
except Exception:
    from main_window import MainWindow  # type: ignore

try:
    from app.ui.widgets.module_with_log import ModuleWithLog
except Exception:
    try:
        from module_with_log import ModuleWithLog
    except Exception:
        ModuleWithLog = object

try:
    from app.ui.widgets.flow_visualizer import FlowVisualizer
except Exception:
    try:
        from flow_visualizer import FlowVisualizer
    except Exception:
        FlowVisualizer = object

# ─────────────────────────────────────────────────────────────
# 메시지 정의 읽기 유틸
def _normalize_defs(defs) -> List[Tuple[str, str]]:
    """다양한 형식의 메시지 정의를 (msg_id, label) 리스트로 통일."""
    out: List[Tuple[str, str]] = []
    if not defs:
        return out
    for item in defs:
        if isinstance(item, dict):
            mid = item.get("id") or item.get("msg_id") or item.get("message_id") or item.get("code")
            name = item.get("name") or item.get("label") or item.get("title") or (f"MSG {mid}" if mid is not None else "MSG")
            if mid is not None:
                out.append((str(mid), str(name)))
        elif isinstance(item, (tuple, list)):
            if len(item) == 2:
                mid, name = item
                out.append((str(mid), str(name)))
            elif len(item) == 1:
                mid = item[0]
                out.append((str(mid), f"MSG {mid}"))
        elif isinstance(item, (int, str)):
            mid = str(item)
            out.append((mid, f"MSG {mid}"))
    return out

def _load_tab_defs() -> Dict[str, Dict[str, List[Tuple[str, str]]]]:
    """
    각 탭의 PUSH/RECEIVE 메시지 정의를 불러와서
    {module_key: {'tx': [(id,label)...], 'rx': [...]} } 형태로 반환
    module_key ∈ {'assignment','monitoring','decision'}
    """
    import importlib
    result = {}
    pairs = [
        ("assignment", "Tabs.assignment_planning_tab", "AssignmentPlanningTab"),
        ("monitoring", "Tabs.mission_monitoring_tab", "MissionMonitoringTab"),
        ("decision",   "Tabs.decision_support_tab",   "DecisionSupportTab"),
    ]
    for key, mod_name, cls_name in pairs:
        tx_defs, rx_defs = [], []
        try:
            mod = importlib.import_module(mod_name)
            cls = getattr(mod, cls_name, None)
            cand_tx = []
            cand_rx = []
            for holder in (mod, cls):
                if holder is None:
                    continue
                if hasattr(holder, "PUSH_MESSAGES"):
                    cand_tx += list(getattr(holder, "PUSH_MESSAGES"))
                if hasattr(holder, "RECEIVE_MESSAGES"):
                    cand_rx += list(getattr(holder, "RECEIVE_MESSAGES"))
            tx_defs = _normalize_defs(cand_tx)
            rx_defs = _normalize_defs(cand_rx)
        except Exception as e:
            sys.stderr.write(f"[WARN] message defs load failed for {mod_name}: {e}\n")
        result[key] = {"tx": tx_defs, "rx": rx_defs}
    return result


# ─────────────────────────────────────────────────────────────
# 대시보드 오케스트레이터 (버튼/목록/카운트/애니메이션/로그)
class DashboardOrchestrator(QObject):
    dashEvent = pyqtSignal(str, str)   # (kind, msg_id) → 메인 스레드에서 _handle_dash_event 호출
    uiLog     = pyqtSignal(str)        # 텍스트 로그를 메인 스레드에서 기록
    def __init__(self, window: MainWindow):
        super().__init__(window)
        self.win = window
        self.widgets = self._resolve_widgets(window)
        self.msg_map = _load_tab_defs()

        self.dashEvent.connect(self._handle_dash_event)
        self.uiLog.connect(self._log_assignment)

        self._init_rows()
        self._connect_launch_buttons()
        self._start_bus_monitor()
        self._start_dashboard_socket()

        # [추가] 앱 시작 시, 초기 모드를 전원 OFF로 강제
        self._set_mode_text_all("전원 OFF")
        self._broadcast_ctrl({"cmd": "mode", "text": "전원 OFF"})

    def _start_dashboard_socket(self):
        """
        모듈 GUI들이 보내는 로컬 UDP 이벤트(kind: 'tx'|'rx', msg_id)를 수신해
        짝 여부와 무관하게 해당 모듈의 OUT/IN을 시각화한다.
        (QTimer.singleShot 대신, cross-thread signal emit 사용 → QThread 경고 제거)
        """
        import socket, json, time, threading

        self._seen_evt_ts = {}  # key -> last_monotonic

        port = int(os.getenv("KU_DASHBOARD_PORT", "45991"))
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("127.0.0.1", port))
        except Exception as e:
            sys.stderr.write(f"[WARN] dashboard UDP bind failed: {e}\n")
            return

        def _dedup(key: str) -> bool:
            now = time.monotonic()
            last = self._seen_evt_ts.get(key, 0.0)
            if (now - last) < 0.15:
                return True
            self._seen_evt_ts[key] = now
            return False

        def loop():
            while True:
                try:
                    data, _ = sock.recvfrom(8192)
                    payload = json.loads(data.decode("utf-8", "ignore"))
                    kind = str(payload.get("kind") or "")
                    mid  = str(payload.get("msg_id") or "")
                    if kind not in ("tx", "rx") or not mid:
                        continue
                    if _dedup(f"udp:{kind}:{mid}"):
                        continue
                    # ⬇️ 변경 포인트: 타이머 대신 시그널 emit ⇒ 메인 스레드에서 처리
                    self.dashEvent.emit(kind, mid)
                except Exception:
                    pass

        threading.Thread(target=loop, daemon=True).start()

    def _norm_code(self, mid) -> str:
        s = str(mid)
        return s.zfill(4) if s.isdigit() and len(s) < 4 else s

    def _handle_dash_event(self, kind: str, msg_id: str):
        """
        UDP로 들어온 이벤트를 모듈 정의에 따라 반영한다.
        kind: 'tx' → OUT, 'rx' → IN
        """
        mid = str(msg_id)
        # UDP와 BUS가 같은 메시지를 거의 동시 전달할 때 중복 반영 방지
        if self._recently_seen(f"udp:{kind}", mid):
            return

        key_to_widget = {
            "assignment": self.widgets.get("assignment"),
            "monitoring": self.widgets.get("monitoring"),
            "decision":   self.widgets.get("decision"),
        }

        for module_key, defs in self.msg_map.items():
            w = key_to_widget.get(module_key)
            if not w:
                continue
            if kind == "tx" and any(m == mid for m, _ in defs.get("tx", [])):
                if hasattr(w, "bump_tx"): w.bump_tx(mid)
                self._animate(module_key, "out")
                if hasattr(w, "append_log"): w.append_log(f"[{mid}] PUSH 완료")
            if kind == "rx" and any(m == mid for m, _ in defs.get("rx", [])):
                if hasattr(w, "bump_rx"): w.bump_rx(mid)
                self._animate(module_key, "in")
                if hasattr(w, "append_log"): w.append_log(f"[{mid}] RX 수신")


    # --------- UI 위젯 해결 ---------
    def _resolve_widgets(self, win):
        # FlowVisualizer: 인스턴스 직접 참조
        flow = getattr(win, "flow", None)
        if flow is None:
            try:
                for fv in win.findChildren(FlowVisualizer):
                    flow = fv
                    break
            except Exception:
                pass

        # 전역 로그 위젯(있으면) - ModuleWithLog 내부(LogBox)는 제외
        log_edit = None
        try:
            from PyQt5.QtWidgets import QTextEdit, QPlainTextEdit
            def _inside_module_with_log(w):
                p = w.parent()
                while p is not None:
                    # 타입 미스매치 방지: 이름 기반으로 회피
                    if getattr(p, "objectName", None) and "ModuleWithLog" in str(type(p)):
                        return True
                    p = p.parent()
                return False

            for ed in win.findChildren((QPlainTextEdit, QTextEdit)):
                name = (ed.objectName() or "").lower()
                if ("log" in name or "logger" in name) and not _inside_module_with_log(ed):
                    log_edit = ed
                    break
            if log_edit is None:
                for ed in win.findChildren((QPlainTextEdit, QTextEdit)):
                    if not _inside_module_with_log(ed):
                        log_edit = ed
                        break
        except Exception:
            pass

        # 모듈 카드: MainWindow 속성 직접 사용(타입 의존 X)
        modules = {
            "assignment": getattr(win, "module_mission",  None),
            "monitoring": getattr(win, "module_monitor",  None),
            "decision":   getattr(win, "module_decision", None),
        }

        # 부족하면 최후의 보정: 순서대로 채우기
        if not all(modules.values()):
            try:
                # 타입 매칭 실패 대비: 모든 위젯 중 title/text로 추정
                candidates = []
                for w in win.findChildren(object):
                    t = ""
                    for attr in ("title", "title_text", "titleLabel", "title_label"):
                        if hasattr(w, attr):
                            obj = getattr(w, attr)
                            try:
                                t = obj if isinstance(obj, str) else obj.text()
                            except Exception:
                                pass
                            if t:
                                break
                    if t:
                        tl = t.lower()
                        if any(k in tl for k in ("할당", "assignment", "계획")) and modules["assignment"] is None:
                            modules["assignment"] = w
                        elif any(k in tl for k in ("모니터", "monitor", "상태")) and modules["monitoring"] is None:
                            modules["monitoring"] = w
                        elif any(k in tl for k in ("의사", "decision", "option", "옵션")) and modules["decision"] is None:
                            modules["decision"] = w
            except Exception:
                pass

        return {"flow": flow, "log_edit": log_edit, **modules}


    def _recently_seen(self, tag: str, mid: str, window: float = 0.3) -> bool:
        """서로 다른 소스(udp/bus) 간 중복 처리 방지용 타임윈도우 디듀프"""
        import time
        t = time.monotonic()
        d = getattr(self, "_seen_any", {})
        key = f"{tag}:{mid}"
        last = d.get(key, 0.0)
        if (t - last) < window:
            return True
        d[key] = t
        self._seen_any = d
        return False
    
    # --------- 초기 목록 채우기 ---------
    def _init_rows(self):
        """
        각 모듈 카드의 송신/수신 목록을 '코드,카운트(초기 0)' 형태로 세팅한다.
        ModuleWithLog.set_tx_rows/set_rx_rows는 [(code, count), ...] 포맷을 기대한다.
        """
        for key, defs in self.msg_map.items():
            mod = self.widgets.get(key)
            if not mod:
                continue

            # (msg_id, msg_name) -> (msg_id, 0) 로 변환
            tx_pairs = [(mid, 0) for (mid, _name) in defs.get("tx", [])]
            rx_pairs = [(mid, 0) for (mid, _name) in defs.get("rx", [])]

            # API 호출
            set_tx = getattr(mod, "set_tx_rows", None)
            if callable(set_tx):
                set_tx(tx_pairs)

            set_rx = getattr(mod, "set_rx_rows", None)
            if callable(set_rx):
                set_rx(rx_pairs)

    def _log_everywhere(self, text: str):
        """
        대시보드 전역 로그 + 3개 모듈 카드에 모두 기록하되,
        동일 카드에 같은 문구가 0.8s 안에 중복 기록되지 않도록 막는다.
        """
        self._append_log_global(text)

        import time
        t = time.monotonic()
        last_map = getattr(self, "_last_card_log", {})  # wid -> (last_text, last_ts)

        # 세 카드에만 브로드캐스트
        for key in ("assignment", "monitoring", "decision"):
            mod = self.widgets.get(key)
            if not mod or not hasattr(mod, "append_log"):
                continue

            wid = id(mod)
            last = last_map.get(wid)
            if last and last[0] == text and (t - last[1]) < 0.2:
                continue

            try:
                mod.append_log(text)
            except Exception:
                pass

            last_map[wid] = (text, t)

        self._last_card_log = last_map

    # --------- 버튼 → 서브프로세스 실행 ---------
    def _connect_launch_buttons(self):
        """
        - 'SW 실행' 버튼 → 세 모듈 GUI를 한 번에 실행
        - '초기화 모드'  → 각 모듈 GUI에 0102(status=1) 버튼을 '실제'로 눌러 ON 상태 보장 + 모드 텍스트 '초기화 모드'
        - '대기모드'     → 0102는 건드리지 않고, 모드 텍스트만 '대기모드'
        - '초기임무계획모드' → 기존 기능 유지(헤드리스 파이프라인 실행)
        """
        try:
            from PyQt5.QtWidgets import QPushButton
        except Exception:
            return

        # ① SW 실행
        btn_all = self._find_button(("sw 실행", "전체 실행", "all run", "launch all", "run all", "전체 구동"))
        if btn_all is not None:
            btn_all.clicked.connect(lambda _=False: self._launch_all_guis())

        # ② 초기화 모드 (구: SW 자체점검)
        btn_self = self._find_button(("초기화 모드", "초기화", "sw 자체점검", "자체점검", "self check", "self-check", "selfcheck"))
        if btn_self is not None:
            try:
                btn_self.clicked.disconnect()
            except Exception:
                pass
            btn_self.clicked.connect(lambda _=False: self._enter_init_reset())  # ← 변경 포인트

        # ③ 대기모드 (0102는 더 이상 OFF 하지 않음)
        btn_standby = self._find_button(("대기모드", "대기", "standby"))
        if btn_standby is not None:
            btn_standby.clicked.connect(lambda _=False: self._enter_standby())

        # ④ 초기임무계획모드 (기능 유지)
        btn_init = self._find_button(("초기임무계획모드", "초기임무계획", "initial", "init plan"))
        if btn_init is not None:
            try:
                btn_init.clicked.disconnect()
            except Exception:
                pass
            btn_init.clicked.connect(lambda _=False: self._enter_initial_plan_and_run())

        # ⑤ 개별 GUI 실행 버튼 바인딩 (동일)
        mapping = {
            "assignment": "mission_planning_gui.py",
            "monitoring": "monitoring_gui.py",
            "decision":   "decision_support_gui.py",
        }
        for key, script in mapping.items():
            card = self.widgets.get(key)
            if not card:
                continue
            btn = getattr(card, "btn_run", None)
            if btn and hasattr(btn, "clicked"):
                try:
                    btn.clicked.disconnect()
                except Exception:
                    pass
                btn.clicked.connect(lambda _=False, sn=script: self._launch_gui(sn))


    def _enter_initial_plan_and_run(self):
        self._set_mode_text_all("초기임무계획")  # 선택
        self._log_assignment("임무 계획 수행 중(main_MP headless, 3세트)…")

        # 오직 headless 3세트 생성만 수행
        self._kickoff_generate_via_main_mp(sets=3)

    def _resolve_db_root(self) -> str:
        """UI 선택 > ENV > <project>/database 우선순위로 DB 루트 결정."""
        from pathlib import Path
        ui_line = getattr(self.win, "_db_path_line", None)
        ui_val = ui_line.text().strip() if ui_line and hasattr(ui_line, "text") else ""
        root = Path(__file__).resolve().parent
        db_root = ui_val or os.environ.get("KU_MISSION_DB_ROOT") or str(root / "database")
        try:
            Path(db_root).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return db_root

    def _kickoff_generate_via_main_mp(self, sets: int = 3):
        """main_MP의 'Generate Mission & Options'를 백그라운드 스레드에서 호출."""
        import threading
        th = threading.Thread(
            target=self._generate_via_main_mp,
            args=(sets,),
            name="InitPlan-By-MainMP",
            daemon=True
        )
        th.start()

    def _generate_via_main_mp(self, sets: int = 3):
        """
        main_MP.generate_mission_and_options_headless(sets) 호출(임포트 우선, 불가 시 CLI 폴백).
        이번 실행에서 생성된 0701/MP만 카운트하도록 mtime 기준으로 엄격 검증.
        검증 통과 후에만 0304→0303→0302→0301→0901 TX를 딱 1회 보냄.
        """
        import os, sys, time, subprocess, importlib
        from pathlib import Path

        db_root = self._resolve_db_root()

        # ── 이번 실행 시작 시각(초) & 기존 0701 제거(조기 통과 차단) ──
        start_ts = time.time()
        opt_path = Path(db_root) / "MissionPlanOptionInfo" / "1.json"
        try:
            if opt_path.exists():
                opt_path.unlink()
        except Exception:
            pass

        # 공통 환경(완전 headless)
        env = os.environ.copy()
        env.setdefault("KU_LAUNCHED_BY_DASHBOARD", "1")
        env["KU_MISSION_DB_ROOT"] = db_root
        env.setdefault("KU_ROLE", "decision")
        env["KU_HEADLESS"] = "1"
        env.setdefault("QT_QPA_PLATFORM", "offscreen")
        env.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")

        tried, ok = [], False

        # 1) import 우선
        for mod_name in (
            "modules.mission_planning.MissionPlanner.main_MP",
            "MissionPlanner.main_MP",
            "main_MP",
        ):
            try:
                mod = importlib.import_module(mod_name)
                if hasattr(mod, "generate_mission_and_options_headless"):
                    self._post_log_assignment(
                        f"[INIT] {mod_name}.generate_mission_and_options_headless(sets={sets}) 호출"
                    )
                    ids = mod.generate_mission_and_options_headless(sets=int(sets), db_root=db_root)
                    ok  = isinstance(ids, (list, tuple)) and len(ids) >= 1
                    break
            except Exception as e:
                tried.append((f"import:{mod_name}", str(e)))

        # 2) 폴백: CLI
        if not ok:
            proj_root  = Path(__file__).resolve().parent
            mp_pkg_dir = proj_root / "modules" / "mission_planning" / "MissionPlanner"
            script     = mp_pkg_dir / "main_MP.py"
            if not script.exists():
                self._post_log_assignment(f"[ERR] main_MP.py 없음: {script}")
                return
            cmd = [
                sys.executable, str(script),
                "--headless", "--generate-options",
                f"--sets={int(sets)}",
                f"--db-root={db_root}",
            ]
            timeout_s = int(os.getenv("KU_MP_HEADLESS_TIMEOUT", "300"))
            try:
                self._post_log_assignment(f"[INIT] subprocess(headless): {' '.join(cmd)}")
                cp = subprocess.run(
                    cmd, cwd=str(mp_pkg_dir), env=env,
                    timeout=timeout_s, capture_output=True, text=True
                )
                ok = (cp.returncode == 0)
                if not ok:
                    tried.append(("subprocess rc",
                                f"rc={cp.returncode}, out={cp.stdout[-300:]}, err={cp.stderr[-300:]}"))
            except Exception as e:
                tried.append(("subprocess ex", str(e)))

        if not ok:
            self._post_log_assignment(f"[ERR] main_MP 위임 실패 details={tried}")
            return

        # 3) 이번 실행 이후 생성분만 인정해서 대기
        ids = self._wait_for_optioninfo(
            db_root, expect_count=int(sets), start_ts=start_ts,
            timeout_s=int(os.getenv("KU_GEN_WAIT_TIMEOUT_S", "300")),
        )
        if len(ids) < int(sets):
            self._post_log_assignment(
                f"[ERR] 생성 대기 타임아웃: 0701/MP 미충족 (got {len(ids)}/{int(sets)}) — TX 생략"
            )
            return

        self._post_log_assignment(f"[OK] {len(ids)}세트 생성 완료. IDs={ids[:int(sets)]}")
        # 4) 이제서야 보내기
        self._pulse_after_external_generation()


    def _wait_for_optioninfo(self, db_root: str, expect_count: int, start_ts: float, timeout_s: int = 300) -> List[int]:
        """
        MissionPlanOptionInfo/1.json 이 이번 실행(start_ts 이후)에 생성/수정되고,
        optionList 개수가 expect_count 이상이며,
        각 missionPlanId의 MissionPlan/<id>.json 도 start_ts 이후에 생성/수정된 경우에만 통과.
        """
        import time, json
        from pathlib import Path

        opt_path = Path(db_root) / "MissionPlanOptionInfo" / "1.json"
        mp_dir   = Path(db_root) / "MissionPlan"

        deadline = time.time() + timeout_s
        noted = 0.0

        def _is_new(p: Path) -> bool:
            try:
                return p.exists() and p.stat().st_mtime >= (start_ts - 0.5)
            except Exception:
                return False

        while time.time() < deadline:
            try:
                if _is_new(opt_path):
                    obj = json.loads(opt_path.read_text(encoding="utf-8"))
                    ids = [int(o["missionPlanId"]) for o in obj.get("optionList", []) if "missionPlanId" in o]
                    # MP 파일들도 이번 실행 이후 생성분만 인정
                    fresh = []
                    for mid in ids:
                        p = mp_dir / f"{int(mid)}.json"
                        if _is_new(p):
                            fresh.append(int(mid))
                    if len(fresh) >= expect_count:
                        return fresh[:expect_count]
            except Exception:
                pass

            now = time.time()
            if now - noted > 4.0:
                self._post_log_assignment("[WAIT] 0701/MP 생성 대기 중…")
                noted = now
            time.sleep(0.6)

        return []

    def _verify_generation(self, db_root: str) -> bool:
        """0701 파일 존재 + MissionPlan ≥ 3개 여부로 강검증."""
        from pathlib import Path
        try:
            root = Path(db_root)
            opt = root / "MissionPlanOptionInfo" / "1.json"
            mps = list((root / "MissionPlan").glob("*.json"))
            return opt.exists() and len(mps) >= 3
        except Exception:
            return False
        
    def _pulse_after_external_generation(self):
        """외부(main_MP) 생성 완료 후: 0304→0303→0302→0301→0901 UI 펄스 + 실제 전송"""
        import threading
        def pulse(code): self._emit_dash_udp("tx", code)
        threading.Timer(0.00, lambda: pulse("0304")).start()
        threading.Timer(0.20, lambda: pulse("0303")).start()
        threading.Timer(0.40, lambda: pulse("0302")).start()
        threading.Timer(1.40, lambda: pulse("0301")).start()
        threading.Timer(1.60, lambda: pulse("0901")).start()
        threading.Timer(1.65, lambda: self._post_log_assignment("초기임무계획 완료(외부생성), 0901 송신")).start()

        # ★ 여기에 현재 UI에서 선택된 DB 루트를 환경변수로 보장
        import os
        os.environ["KU_MISSION_DB_ROOT"] = self._resolve_db_root()

        from dll_files.nFusionImports import NodeMessenger
        from push_center import push_message
        threading.Timer(0.00, lambda: push_message("0304", NodeMessenger)).start()
        threading.Timer(0.25, lambda: push_message("0303", NodeMessenger)).start()
        threading.Timer(0.50, lambda: push_message("0302", NodeMessenger)).start()
        threading.Timer(1.30, lambda: push_message("0301", NodeMessenger)).start()
        threading.Timer(1.55, lambda: push_message("0901", NodeMessenger)).start()  # 0701은 DS가 자동 클릭


    def _enter_init_reset(self):
        """
        초기화 모드:
          - 각 모듈의 TX 테이블에서 0102를 '실제 버튼 토글 경로'로 ON 상태 보장
          - 대시보드/모듈 모드 텍스트: '초기화 모드'
        """
        self._self_check_all(True)  # 내부적으로 각 GUI에서 0102 버튼 click() 시도 → 폴백 push 포함
        self._set_mode_text_all("초기화 모드")
        self._broadcast_ctrl({"cmd": "mode", "text": "초기화 모드"})
        self._log_everywhere("모든 SW 초기화 모드(0102 ON)")


    def _after_save_sequence(self):
        """
        저장 후:
        - 0.2초 간격으로 0304 → 0303 → 0302
        - 추가 1초 뒤 0301
        - 그 뒤 완료 로그
        (Qt 타이머 대신 threading.Timer 사용 → QThread 경고 제거)
        """
        import threading
        if os.environ.get("KU_HEADLESS") == "1":
            return

        def pulse(code):
            self._emit_dash_udp("tx", code)

        threading.Timer(0.0,  lambda: pulse("0304")).start()
        threading.Timer(0.2,  lambda: pulse("0303")).start()
        threading.Timer(0.4,  lambda: pulse("0302")).start()
        threading.Timer(1.4,  lambda: pulse("0301")).start()
        threading.Timer(1.45, lambda: self._post_log_assignment("초기 임무 계획 모드 완료")).start()

        # ★ 여기서도 동일하게 보장
        import os
        os.environ["KU_MISSION_DB_ROOT"] = self._resolve_db_root()

        from dll_files.nFusionImports import NodeMessenger
        from push_center import push_message
        threading.Timer(0.00, lambda: push_message("0304", NodeMessenger)).start()
        threading.Timer(0.25, lambda: push_message("0303", NodeMessenger)).start()
        threading.Timer(0.50, lambda: push_message("0302", NodeMessenger)).start()
        threading.Timer(1.30, lambda: push_message("0301", NodeMessenger)).start()
        threading.Timer(1.55, lambda: push_message("0901", NodeMessenger)).start()


    def _emit_dash_udp(self, kind: str, msg_id: str):
        """
        대시보드 수신 포트(KU_DASHBOARD_PORT, 기본 45991)로 UDP 이벤트 전송
        kind: 'tx' | 'rx'
        """
        import os, socket, json
        port = int(os.getenv("KU_DASHBOARD_PORT", "45991"))
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            payload = json.dumps({"kind": kind, "msg_id": str(msg_id)}).encode("utf-8")
            s.sendto(payload, ("127.0.0.1", port))
        finally:
            try:
                s.close()
            except Exception:
                pass

    def _log_assignment(self, text: str):
        """즉시(동기) 호출 시: 할당 카드 + 전역 로그에 남김"""
        mod = self.widgets.get("assignment")
        if mod and hasattr(mod, "append_log"):
            try:
                mod.append_log(text)
            except Exception:
                pass
        self._append_log_global(text)

    def _post_log_assignment(self, text: str):
        """
        백그라운드 스레드에서 안전하게 호출하는 로그 기록기.
        메인 스레드로 시그널만 보낸다.
        """
        try:
            self.uiLog.emit(str(text))
        except Exception:
            try:
                print(text)
            except Exception:
                pass
            

    def _self_check_all(self, on: bool = True):
        """모든 모듈 GUI에 자체점검 0102 On/Off 명령 전송"""
        payload = {"cmd": "self_check", "status": 1 if on else 0}
        self._broadcast_ctrl(payload)
        self._log_everywhere(f"자체점검 0102 {'ON' if on else 'OFF'} 전송")

    def _enter_standby(self):
        """
        대기모드:
          - 0102는 더 이상 건드리지 않음(요청사항 반영)
          - 대시보드/모듈 모드 텍스트만 '대기모드'로
        """
        # self._self_check_all(False)  # ← 삭제(0102 OFF 취소)
        self._set_mode_text_all("대기모드")
        self._broadcast_ctrl({"cmd": "mode", "text": "대기모드"})
        self._log_everywhere("모든 SW 대기모드 진입")

    def _enter_initial_plan(self):
        """초기임무계획: 0102 Off + 대시보드 모드텍스트 '초기임무계획'"""
        self._self_check_all(False)
        self._set_mode_text_all("초기임무계획")
        self._broadcast_ctrl({"cmd": "mode", "text": "초기임무계획"})
        self._log_everywhere("모든 SW 초기임무계획 모드")

    def _set_mode_text_all(self, text: str):
        """대시보드의 세 카드(할당/모니터/의사) 'Mode 모니터링 txt' 표시 갱신"""
        for key in ("assignment", "monitoring", "decision"):
            mod = self.widgets.get(key)
            if not mod:
                continue
            # ModuleWithLog 전용 API 우선
            if hasattr(mod, "set_mode_text") and callable(mod.set_mode_text):
                try:
                    mod.set_mode_text(text)
                    continue
                except Exception:
                    pass
            # 백업: 속성 직접 접근
            try:
                ml = getattr(mod, "mode_line", None)
                if ml is not None and hasattr(ml, "setText"):
                    ml.setText(text)
            except Exception:
                pass

    def _broadcast_ctrl(self, payload: dict):
        """
        로컬 UDP로 각 모듈 GUI에 제어 명령 전달.
        포트 규약:
        - mission_planning_gui.py : 45981 (assignment)
        - monitoring_gui.py       : 45982 (monitoring)
        - decision_support_gui.py : 45983 (decision)
        """
        import socket, json
        targets = [("assignment", 45981), ("monitoring", 45982), ("decision", 45983)]
        data = json.dumps(payload).encode("utf-8")
        for role, port in targets:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.sendto(data, ("127.0.0.1", port))
                s.close()
            except Exception as e:
                try:
                    import sys
                    sys.stderr.write(f"[WARN] CTRL send to {role}:{port} failed: {e}\n")
                except Exception:
                    pass


    def _launch_all_guis(self):
        """
        'SW 실행' 버튼 액션: 세 모듈 GUI를 순차 실행
        """
        for sn in ("mission_planning_gui.py", "monitoring_gui.py", "decision_support_gui.py"):
            self._launch_gui(sn)

        # ★ GUI들이 CTRL UDP 바인드 시간을 가진 뒤, 메인스레드에서 전원 ON 브로드캐스트
        QTimer.singleShot(1000, lambda: self._set_mode_text_all("전원 ON"))
        QTimer.singleShot(1000, lambda: self._broadcast_ctrl({"cmd": "mode", "text": "전원 ON"}))
        QTimer.singleShot(1000, lambda: self._log_everywhere("모든 SW 전원 ON"))

    def _find_button(self, keywords) -> Optional[object]:
        """
        주어진 키워드가 텍스트/오브젝트명이에 포함된 첫 QPushButton을 찾는다.
        (한글 '실행' 도 매칭되도록 단순화)
        """
        try:
            from PyQt5.QtWidgets import QPushButton
            for btn in self.win.findChildren(QPushButton):
                text = (btn.text() or "").lower()
                objn = (btn.objectName() or "").lower()
                if any(k in text for k in keywords) or any(k in objn for k in keywords):
                    return btn
        except Exception:
            pass
        return None
    

    def _launch_gui(self, script_name: str):
        """
        GUI 스크립트 탐색 우선순위를 확장 + 자식 프로세스에 KU_MISSION_DB_ROOT 주입
        """
        import sys, os, subprocess
        from pathlib import Path

        # 프로젝트 루트
        root = Path(__file__).resolve().parent
        modules_dir = root / "modules"

        candidates = [
            root / script_name,
            modules_dir / "mission_planning" / script_name,
            modules_dir / "monitoring" / script_name,
            modules_dir / "decision_support" / script_name,
        ]
        script = next((p for p in candidates if p.exists()), None)
        if script is None:
            try:
                # 카드 로그가 있다면 거기에 남김 (없으면 조용히 무시)
                mod = getattr(self.widgets, "get", lambda *_: None)("decision")
                if mod and hasattr(mod, "append_log"):
                    mod.append_log(f"[RUN ERR] not found: {script_name}")
            except Exception:
                pass
            return

        # ── ★ DB 루트 경로 결정 ─────────────────────────────────────
        # 우선순위: (1) UI에서 고른 경로 → (2) 기존 ENV → (3) <프로젝트루트>\database
        ui_line = getattr(self.win, "_db_path_line", None)
        ui_val = ui_line.text().strip() if ui_line and hasattr(ui_line, "text") else ""

        db_root = ui_val or os.environ.get("KU_MISSION_DB_ROOT") or str(root / "database")
        # 존재하지 않으면 만들어 둠(하위 폴더는 각 GUI에서 생성)
        try:
            Path(db_root).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        # ── 자식 환경 구성 ──────────────────────────────────────────
        env = os.environ.copy()
        env.setdefault("KU_LAUNCHED_BY_DASHBOARD", "1")
        env["KU_MISSION_DB_ROOT"] = db_root   # ★ 여기!

        # ⬇️ 여기를 “정석 매핑”으로 교체
        port_map = {
            "mission_planning_gui.py" : "45981",  # Assignment(MMR)
            "monitoring_gui.py"       : "45982",  # Monitoring(MSM)
            "decision_support_gui.py" : "45983",  # Decision(MOB)
        }
        try:
            script_basename = script.name
        except Exception :
            script_basename = script_name
        env["KU_CTRL_PORT"] = port_map.get(script_basename, port_map.get(script_name, ""))

        try:
            subprocess.Popen(
                [sys.executable, str(script)],
                cwd=str(root),
                env=env,
                start_new_session=True
            )
        except Exception as e:
            try:
                mod = getattr(self.widgets, "get", lambda *_: None)("decision")
                if mod and hasattr(mod, "append_log"):
                    mod.append_log(f"[RUN ERR] {e}")
            except Exception:
                pass

    # --------- 버스 모니터링 시작 ---------
    def _start_bus_monitor(self):
        """
        대시보드(run.py 프로세스)를 nFusion 버스에 가입시키고,
        모든 메시지 ID에 대해 self(mark_received)를 리스너로 등록한다.
        !! 중요: receive 패키지를 import하기 전에 MessageLibrary를 AddReference 해야 한다.
        """
        # 0) 설정/어셈블리 선로딩 (← 순서 중요)
        try:
            _ensure_fusion_configs()
        except Exception:
            pass
        try:
            _load_msglib_and_deps()  # MessageLibrary + 의존 DLL 로드
        except Exception as e:
            sys.stderr.write(f"[WARN] _load_msglib_and_deps failed: {e}\n")

        # 1) receive 패키지 로드(Consumer 타입 등록을 위해 필수)
        try:
            import receive  # noqa: F401  # 이제 .NET 네임스페이스가 열려 있어야 정상 import됨
        except Exception as e:
            sys.stderr.write(f"[WARN] failed to import receive: {e}\n")
            return

        # 2) 리스너 등록 API 확보
        try:
            from receive_center import register_listener as register_listener  # 루트
        except Exception:
            try:
                from modules.common.receive_center import register_listener as register_listener  # 공용
            except Exception as e:
                sys.stderr.write(f"[WARN] receive_center.register_listener not available: {e}\n")
                return

        # 3) 우리 프로세스가 받을 메시지 ID 전체를 수집 후 리스너로 self 등록
        all_ids = set()
        for defs in self.msg_map.values():
            for mid, _ in (defs.get("tx", []) + defs.get("rx", [])):
                all_ids.add(str(mid))
        for mid in sorted(all_ids):
            try:
                register_listener(mid, self)  # 수신 시 self.mark_received(...) 호출됨
            except Exception as e:
                sys.stderr.write(f"[WARN] register_listener({mid}) failed: {e}\n")

        # 4) 버스 초기화(서브스크라이버/컨슈머 등록 포함)
        def _rx_setup():
            try:
                from dll_files.nFusionImports import FusionNodeIoc, NodeMessenger  # noqa
                FusionNodeIoc.Configure()
                NodeMessenger.Initialize("CommonChannel")
                NodeMessenger.RegistAllConsumerFromFusionNodeIoc()
                NodeMessenger.InitAllSubscriberFromAssembly()
                NodeMessenger.RegistAllProviderFromFusionNodeIoc()
            except Exception as e:
                sys.stderr.write(f"[WARN] NodeMessenger init failed: {e}\n")

        threading.Thread(target=_rx_setup, daemon=True).start()

    def mark_received(self, msg_id: str, raw: bytes | None = None):
        mid = self._norm_code(msg_id)

        # --- raw에서 source 추출(MMR/MSM/MOB 또는 한글 풀네임) ---
        src_key = None
        if raw:
            try:
                import re, json
                txt = raw.decode("utf-8", "ignore")
                m = re.search(r"\{.*\}", txt, flags=re.S)
                if m:
                    obj = json.loads(m.group(0))
                    src = obj.get("SourceModuleName") or obj.get("source") or obj.get("requestModuleName")
                    if src:
                        s = str(src).upper()
                        if "MMR" in s or "MULTI-AGENT MISSION PLANNER" in s:
                            src_key = "assignment"
                        elif "MSM" in s or "MISSION STATE MONITOR" in s:
                            src_key = "monitoring"
                        elif "MOB" in s or "MISSION OPTION BUILDER" in s:
                            src_key = "decision"
            except Exception:
                pass

        # --- 디듀프: 모듈별로 분리 + 5Hz 고려해 0.02s ---
        tag = f"bus:{src_key or 'all'}"
        if self._recently_seen(tag, mid, window=0.02):
            return

        key_to_widget = {
            "assignment": self.widgets.get("assignment"),
            "monitoring": self.widgets.get("monitoring"),
            "decision":   self.widgets.get("decision"),
        }

        # 업데이트 대상 모듈 결정
        if src_key:
            targets = [src_key]
        else:
            # 소스가 불명확하면 메시지 정의에 따라 모두 반영(기존 맵)
            targets = []
            for key, defs in self.msg_map.items():
                tx = {m for m, _ in defs.get("tx", [])}
                rx = {m for m, _ in defs.get("rx", [])}
                if mid in tx or mid in rx:
                    targets.append(key)

        # 반영
        for module_key in targets:
            w = key_to_widget.get(module_key)
            if not w:
                continue
            defs = self.msg_map.get(module_key, {})
            tx_ids = {m for m, _ in defs.get("tx", [])}
            rx_ids = {m for m, _ in defs.get("rx", [])}

            touched = False
            if mid in tx_ids and hasattr(w, "bump_tx"):
                w.bump_tx(mid)
                self._animate(module_key, "out")
                if hasattr(w, "append_log"): w.append_log(f"[{mid}] PUSH 완료")
                touched = True

            if mid in rx_ids and hasattr(w, "bump_rx"):
                w.bump_rx(mid)
                self._animate(module_key, "in")
                if hasattr(w, "append_log"): w.append_log(f"[{mid}] RX 수신")
                touched = True


    def _animate(self, module_key: str, direction: str):
        # module_key: 'assignment' | 'monitoring' | 'decision'
        vis_key = {"assignment": "mission", "monitoring": "monitor", "decision": "decision"}.get(module_key, module_key)

        # 1) MainWindow에 내장된 헬퍼가 있으면 그것부터 사용(동일 로직 보장)
        fnp = getattr(self.win, "_pulse", None)
        if callable(fnp):
            try:
                fnp(vis_key, direction)
                return
            except Exception:
                pass

        # 2) 직접 flow.trigger 호출
        flow = self.widgets.get("flow")
        if not flow:
            return
        fn = getattr(flow, "trigger", None)
        if callable(fn):
            try:
                fn(vis_key, direction)
            except Exception:
                pass


    def _append_log_global(self, text: str):
        ed = self.widgets.get("log_edit")
        if ed is None:
            return
        # 안전장치: 전역 로그로 잡힌 위젯이 ModuleWithLog 내부라면 쓰지 않음
        try:
            p = ed.parent()
            while p is not None:
                if isinstance(p, ModuleWithLog):
                    return  # 카드 안의 LogBox면 전역 로그로 쓰지 않음
                p = p.parent()
        except Exception:
            pass

        try:
            if isinstance(ed, QPlainTextEdit):
                ed.appendPlainText(text)
            elif isinstance(ed, QTextEdit):
                ed.append(text)
        except Exception:
            pass



# ─────────────────────────────────────────────────────────────
def main():
    app = QApplication(sys.argv)
    _load_qss(app)
    win = MainWindow()
    win.show()
    # 오케스트레이터 구동(버튼 연결, 목록/카운트/애니메이션/로그)
    orch = DashboardOrchestrator(win)
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()