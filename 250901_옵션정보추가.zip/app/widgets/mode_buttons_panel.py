# /mnt/data/mode_buttons_panel.py  (파일 전체 교체)
# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QSizePolicy
from PyQt5 import QtCore

class ModeButtonsPanel(QWidget):
    """
    모드 버튼 영역 (창 프레임 없음).
    - 총 5개 버튼을 전체 영역에 꽉 차게 배치
    - 버튼 간 상하 간격은 균등하게 늘어남
    """
    initialMissionPlanningRequested = QtCore.Signal() if hasattr(QtCore, "Signal") else QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(20)

        button_specs = [
            ("SW 실행",          "btn_sw_run"),
            ("초기화 모드",       "btn_self_check"),   # ← 라벨 변경(구: SW 자체점검)
            ("대기모드",          "btn_standby"),
            ("초기임무계획모드",  "btn_init_plan"),
            ("임무 수행 모드",    "btn_mission_mode"),
            # ("운용자 입력 GUI", "btn_operator_gui"),  # ← 삭제
        ]

        for text, objname in button_specs:
            btn = QPushButton(text, self)
            btn.setObjectName(objname)          # QSS 타깃팅/검색용
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            lay.addWidget(btn, 1)

    def on_click_initial_mission_planning(self):
        self.initialMissionPlanningRequested.emit()
