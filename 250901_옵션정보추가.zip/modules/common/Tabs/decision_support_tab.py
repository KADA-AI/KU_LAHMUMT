# 파일: /mnt/data/decision_support_tab.py
# -*- coding: utf-8 -*-
from Tabs.csc_tab_base import CSCTabBase
import time

_EPOCH2000_MS = 946684800000
def _now_ms_since_2000():
    return int(time.time() * 1000) - _EPOCH2000_MS

class DecisionSupportTab(CSCTabBase):
    TITLE = "의사결정 지원 CSC"
    
    # **FB → Push**
    PUSH_MESSAGES = [
        ("0102", "모듈 상태 정보"),
        ("0701", "의사결정 옵션정보"),
    ]
    
    # **BF → Receive**
    RECEIVE_MESSAGES = [
        ("0101", "시스템 운용 모드"),
        ("0201", "협업기저임무 계획"),
        ("0202", "선행임무정보"),
        ("0203", "비행참조정보"),
        ("0301", "임무 계획"),
        ("0302", "개별 임무 계획"),
        ("0303", "무인기 비행 계획"),
        ("0304", "LAH 비행 계획"),
        ("0401", "유무인기 상태정보"),
        ("0402", "전장상황인지정보"),
        ("0501", "임무수행상태정보"),
        ("0701", "의사결정 옵션정보"),
        ("0806", "시스템 부팅 명령"),
        ("0901", "옵션 정보 생성 요청"),
    ]

    # ★ 오버라이드: 0102만 수동 바디(빈 dict) → 나머지는 기본(모듈/DB) 경로 사용
    def _build_overridden_body(self, msg_id: str):
        mid = str(msg_id).strip()
        if mid == "0102":
            return {}  # 0102만 기본 생성 규칙 사용(토글/상태 확인용)
        # ⬇ 0701 강제 주입 제거: DB/푸시 모듈 경로로 생성되도록 None 반환
        return None
