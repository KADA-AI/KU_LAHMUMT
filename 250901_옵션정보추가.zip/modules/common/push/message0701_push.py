# 파일: modules/common/push/message0701_push.py
# auto-generated at 2025-08-24T20:13:14.031500+00:00

import json, importlib, os
from datetime import datetime, timezone
from pathlib import Path
from System.Collections.Generic import List
from nFusion.Model.msg_0701 import *    # C# 모델(우선)
from nFusion.Model.CommonType import *  # 공통 타입(항상)
from System import Boolean, Int32, String, UInt32, UInt64
from generator.message0701_generator import make_msg0701_body

_EPOCH_2000 = datetime(2000, 1, 1, tzinfo=timezone.utc)
_now_ms = lambda: int((datetime.utcnow().replace(tzinfo=timezone.utc) - _EPOCH_2000).total_seconds() * 1000)
MSG_ID = "0701"

def _try_set(obj, name: str, value) -> bool:
    # lowerCamel 또는 PascalCase 둘 다 시도
    for k in (name, name[:1].upper()+name[1:] if name else name):
        try:
            if hasattr(obj, k):
                setattr(obj, k, value)
                return True
        except Exception:
            pass
    return False

def _cs(name: str):
    # 현재 전역 → msg_ID 모듈 → CommonType → 루트 순으로 검색
    t = globals().get(name)
    if t is not None: return t
    for modname in (f'nFusion.Model.msg_{MSG_ID}', 'nFusion.Model.CommonType', 'nFusion.Model'):
        try:
            mod = importlib.import_module(modname)
            t = getattr(mod, name, None)
            if t is not None: return t
        except Exception:
            pass
    return None

def _new(name: str):
    t = _cs(name)
    if t is None:
        raise NameError(f'type not found: {name}')
    return t()

# ── Embedded TX/DB rules (self-contained) ──────────────────────────────────
TX_FIELD_WHITELIST = {
    "0201": ["timestamp", "inputMissionPackageID"],
    "0203": ["timestamp", "missionReferencePackageID"],
    "0301": ["timestamp", "missionPlanID"],
    "0302": ["timestamp", "individualMissionPackageID"],
    "0303": ["timestamp", "pathID"],
    "0304": ["timestamp", "pathID"],
}
DB_DIR_RULES = {
    "0201": "InputMissionPlan",
    "0203": "FlightReferenceInfo",
    "0301": "MissionPlan",
    "0302": "IndividualMissionPlan",
    "0303": "FlightPath",
    "0304": "FlightPath",
    # 0701은 개별 파일(1.json) 단일 경로 사용 → 별도 처리
}

def _select_tx_fields(body: dict, fields: list) -> dict:
    """화이트리스트로 선별: timestamp / source 계열 폴백 / 나머지 ID류만 남김"""
    out = {}
    low = {k.lower(): k for k in body.keys()}

    def _get(key: str):
        kl = key.lower()
        if kl in low:
            return body[low[kl]]
        return None

    ts = _get("timestamp")
    if ts is not None:
        out["timestamp"] = int(ts)

    s  = _get("source")
    sm = _get("sourceModuleName") or _get("sourcemodulename")
    rq = _get("requestModuleName") or _get("requestmodulename")
    src_val = s or sm or rq
    if src_val:
        out["sourceModuleName"] = str(src_val)

    for f in fields:
        if f in ("timestamp","source","sourceModuleName","requestModuleName"):
            continue
        v = _get(f)
        if v is not None:
            try:
                out[f] = int(v)
            except Exception:
                out[f] = v
    return out

def _project_root_for_push_file(__file_path: str):
    return Path(__file_path).resolve().parents[3]

def _db_dir_for(msgid: str, __file_path: str) -> str:
    env_root = os.getenv("KU_MISSION_DB_ROOT")
    name = DB_DIR_RULES.get(msgid, f"msg_{msgid}")
    if env_root:
        return str(Path(env_root) / name)
    return str(_project_root_for_push_file(__file_path) / "database" / name)

def _list_numeric_ids(dirname: str, prefix_first_char: str | None = None) -> list[int]:
    import glob
    ids = []
    for p in glob.glob(os.path.join(dirname, "*.json")):
        stem = os.path.splitext(os.path.basename(p))[0]
        if stem.isdigit():
            if prefix_first_char and stem[0] not in prefix_first_char:
                continue
            ids.append(int(stem))
    ids.sort()
    return ids

# ── 0701 모델 변환 ─────────────────────────────────────────────────────────
def _dict_to_UAVMissionPlanID(data: dict):
    obj = _new('UAVMissionPlanID')
    if "uavMissionPlanID" in data: _try_set(obj, "uavMissionPlanID", int(data["uavMissionPlanID"]))
    return obj

def _dict_to_LAHMissionPlanID(data: dict):
    obj = _new('LAHMissionPlanID')
    if "lahMissionPlanID" in data: _try_set(obj, "lahMissionPlanID", int(data["lahMissionPlanID"]))
    return obj

def _dict_to_Option(data: dict):
    obj = _new('Option')
    if "optionID" in data: _try_set(obj, "optionID", int(data["optionID"]))
    if "optionName" in data: _try_set(obj, "optionName", int(data["optionName"]))
    if "missionPlanID" in data: _try_set(obj, "missionPlanID", int(data["missionPlanID"]))
    if "survivalRate" in data: _try_set(obj, "survivalRate", int(data["survivalRate"]))
    if "timeContraction" in data: _try_set(obj, "timeContraction", int(data["timeContraction"]))
    if "recogEffectiveness" in data: _try_set(obj, "recogEffectiveness", int(data["recogEffectiveness"]))
    if "distance" in data: _try_set(obj, "distance", int(data["distance"]))
    if "target" in data: _try_set(obj, "target", int(data["target"]))
    if "uavMissionPlanIDList" in data and isinstance(data["uavMissionPlanIDList"], list):
        T = _cs('UAVMissionPlanID') or object
        lst = List[T]()
        for item in data["uavMissionPlanIDList"]: lst.Add(_dict_to_UAVMissionPlanID(item if isinstance(item, dict) else {}))
        _try_set(obj, "uavMissionPlanIDList", lst)
    if "lahMissionPlanIDList" in data and isinstance(data["lahMissionPlanIDList"], list):
        T = _cs('LAHMissionPlanID') or object
        lst = List[T]()
        for item in data["lahMissionPlanIDList"]: lst.Add(_dict_to_LAHMissionPlanID(item if isinstance(item, dict) else {}))
        _try_set(obj, "lahMissionPlanIDList", lst)
    return obj

def _dict_to_MissionPlanOptionInfo(data: dict):
    obj = _new('MissionPlanOptionInfo')
    if "timestamp" in data: _try_set(obj, "timestamp", int(data["timestamp"]))
    val_src = data.get("source", data.get("source", data.get("sourceModuleName", data.get("requestModuleName", ""))))
    if val_src != "":
        if not _try_set(obj, "source", str(val_src)):
            _try_set(obj, "sourceModuleName", str(val_src))
    if "autoExecution" in data: _try_set(obj, "autoExecution", bool(data["autoExecution"]))
    if "optionList" in data and isinstance(data["optionList"], list):
        T = _cs('Option') or object
        lst = List[T]()
        for item in data["optionList"]: lst.Add(_dict_to_Option(item if isinstance(item, dict) else {}))
        _try_set(obj, "optionList", lst)
    return obj

def _dict_to_obj(body_dict: dict):
    return _dict_to_MissionPlanOptionInfo(body_dict)

def make_and_push(body_dict: dict, node_messenger) -> bytes:
    # 0701은 화이트리스트 적용하지 않음(옵션 상세 유지)
    wl = TX_FIELD_WHITELIST.get(MSG_ID)
    if wl and isinstance(body_dict, dict):
        body_dict = _select_tx_fields(body_dict, wl)
    msg = _dict_to_obj(body_dict)
    node_messenger.Push(msg)
    log_line = (
        f"[0701] BODY  : {json.dumps(body_dict, ensure_ascii=False)}\n"
        f"[0701] PUSH 완료"
    )
    return log_line.encode("utf-8", "ignore")

def make_random_and_push(node_messenger) -> bytes:
    """
    0701: DB(MissionPlanOptionInfo/1.json)가 있으면 그걸 우선 사용해 단발 push.
         없으면 제너레이터(make_msg0701_body)로 폴백.
    기타 MSG_ID: 기존 동작 유지.
        """
    if MSG_ID == "0701":
        print("[0701] try DB first")
        res = make_from_db_and_push(node_messenger)
        if res is not None:
            print("[0701] DB used")
            return res
        print("[0701] fallback to template")
        # DB가 없거나 파싱 실패 시에만 템플릿 폴백
        body = make_msg0701_body()
        return make_and_push(body, node_messenger)

    # ===== 이하 다른 MSG_ID의 기존 로직 유지 =====
    if MSG_ID in DB_DIR_RULES:
        dbdir = _db_dir_for(MSG_ID, __file__)
        needs_prefix = "123" if MSG_ID == "0304" else None
        ids = _list_numeric_ids(dbdir, needs_prefix)
        logs = []
        for vid in ids:
            wl = TX_FIELD_WHITELIST.get(MSG_ID, [])
            body = {
                "timestamp": int((datetime.utcnow().replace(tzinfo=timezone.utc) - _EPOCH_2000).total_seconds() * 1000),
                "sourceModuleName": "DSC",
            }
            if "inputMissionPackageID" in wl:          body["inputMissionPackageID"] = vid
            if "missionReferencePackageID" in wl:      body["missionReferencePackageID"] = vid
            if "missionPlanID" in wl:                  body["missionPlanID"] = vid
            if "individualMissionPackageID" in wl:     body["individualMissionPackageID"] = vid
            if "pathID" in wl:                         body["pathID"] = vid
            logs.append(make_and_push(body, node_messenger))
        return b"\n".join(logs) if logs else b""
    else:
        body = make_msg0701_body()
        if MSG_ID == "0102":
            if not isinstance(body, dict) or not body:
                body = {
                    "timestamp": int((datetime.utcnow().replace(tzinfo=timezone.utc) - _EPOCH_2000).total_seconds() * 1000),
                    "status": 1,
                    "sourceModuleName": "DSC",
                }
        wl = TX_FIELD_WHITELIST.get(MSG_ID)
        if wl and isinstance(body, dict):
            body = _select_tx_fields(body, wl)
        return make_and_push(body, node_messenger)

# ── 0701 전용: DB에서 읽어 한 번에 push ─────────────────────────────────────
def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]

def _now_ms_2000() -> int:
    return _now_ms()

def _get_path_0701_optioninfo() -> Path:
    env_root = os.getenv("KU_MISSION_DB_ROOT")
    if env_root:
        return Path(env_root) / "MissionPlanOptionInfo" / "1.json"
    return _project_root() / "database" / "MissionPlanOptionInfo" / "1.json"

def make_from_db_and_push(node_messenger) -> bytes | None:
    """
    MissionPlanOptionInfo/1.json을 그대로 읽어 optionList를 구성해 0701 단발 push.
    - missionPlanID 케이스 정규화
    - optionID/optionName 미존재 시 보정(기본값)
    - source/autoExecution 그대로 패스스루
    """
    p = _get_path_0701_optioninfo()
    if not p.exists():
        return None
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None

    raw_list = obj.get("optionList") or obj.get("OptionList") or []
    option_list = []
    for i, o in enumerate(raw_list, start=1):
        it = dict(o)  # DB 값을 최대한 유지
        if "missionPlanID" not in it:
            for k in ("missionPlanId", "missionplanid"):
                if k in it:
                    try:
                        it["missionPlanID"] = int(it.pop(k))
                    except Exception:
                        it["missionPlanID"] = it.pop(k)
                    break
        # 기본값 보정(없을 때만)
        it.setdefault("optionID", i)
        it.setdefault("optionName", it["optionID"])
        option_list.append(it)

    body = {
        "timestamp":     _now_ms_2000(),
        "source":        obj.get("source") or obj.get("sourceModuleName") or obj.get("requestModuleName") or "MOB",
        "autoExecution": bool(obj.get("autoExecution", False)),
        "optionList":    option_list,
    }
    return make_and_push(body, node_messenger)
