import importlib, socket, json, os

_DASH_PORT = int(os.getenv("KU_DASHBOARD_PORT", "45991"))

# 필요시 동적으로 늘릴 수 있게 리스트로 관리
SEARCH_PREFIXES = [
    "generator",                          # ✅ 새로 추가: 최우선으로 generator/ 를 탐색
    "push_info",                          # 공용 push_info
    "push",                               # 공용 push
    "modules.common.push_info",           # 명시 common
    "modules.common.push",
    "modules.decision_support.push_info", # DS fallback
    "modules.decision_support.push",
]

def push_message(msg_id: str, messenger, *, on_done=None, body_dict=None) -> bool:
    import importlib, inspect

    msg = str(msg_id).zfill(4)

    # ── 0701만 modules.common.push 우선으로 탐색 (DB 기반 구현 사용)
    if msg == "0701":
        prefixes = [
            "modules.common.push",           # ← 당신이 수정한 파일이 여기
            "modules.common.push_info",
            "push_info",
            "push",
            "modules.decision_support.push_info",
            "modules.decision_support.push",
            "generator",                     # ← 제너레이터는 맨 마지막
        ]
    else:
        prefixes = SEARCH_PREFIXES  # 기존 그대로

    last_exc = None
    mod = None
    for pref in prefixes:
        try:
            mod = importlib.import_module(f"{pref}.message{msg}_push")
            if msg == "0701":
                # 확인용 로그(필요 없으면 주석 처리 가능)
                print(f"[push_center] 0701 resolved → {mod.__name__} :: {getattr(mod,'__file__','?')}")
            break
        except Exception as e:
            last_exc = e
    if mod is None:
        raise last_exc or ImportError(f"message{msg}_push not found in {prefixes}")

    # ── 호출: body_dict 유무에 따라 안전하게
    def _try_call(fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except TypeError:
            return None

    raw = None
    if hasattr(mod, "make_and_push") and body_dict is not None:
        # 시그니처 혼재 대응: (body_dict, messenger) → (messenger, body_dict) 순으로 시도
        raw = _try_call(mod.make_and_push, body_dict, messenger)
        if raw is None:
            raw = _try_call(mod.make_and_push, messenger, body_dict)
        if raw is None:
            # 키워드 인자 지원 모듈 대응
            try:
                raw = mod.make_and_push(body_dict=body_dict, node_messenger=messenger)
            except TypeError:
                try:
                    raw = mod.make_and_push(node_messenger=messenger, body_dict=body_dict)
                except TypeError:
                    pass

    if raw is None:
        if hasattr(mod, "make_random_and_push"):
            raw = mod.make_random_and_push(messenger)
        elif hasattr(mod, "push"):
            # (messenger) / (body_dict, messenger) / (messenger, body_dict) 모두 시도
            raw = _try_call(mod.push, messenger) \
               or _try_call(mod.push, body_dict, messenger) \
               or _try_call(mod.push, messenger, body_dict)
            if raw is None:
                try:
                    raw = mod.push(node_messenger=messenger, body_dict=body_dict)
                except TypeError:
                    try:
                        raw = mod.push(body_dict=body_dict, node_messenger=messenger)
                    except TypeError:
                        pass

    if raw is None:
        raise AttributeError(f"{mod.__name__} has no usable push entrypoint")

    if on_done:
        try:
            on_done(msg, raw)
        except Exception:
            pass
    return True