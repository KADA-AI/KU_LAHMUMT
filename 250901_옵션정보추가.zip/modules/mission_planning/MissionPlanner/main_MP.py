# main_MP.py — headless-safe import block
import os
import sys
import time
import json
import math
import shutil
import tempfile
from pathlib import Path
from itertools import cycle

# Qt: WebEngine 사용 전, 반드시 OpenGL 공유 속성 세팅
from PyQt5.QtCore import QCoreApplication, Qt, QUrl
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QPushButton, QTextEdit, QTabWidget, QFrame,
    QComboBox, QDialog, QPlainTextEdit, QFileDialog, QMessageBox, QLabel
)
from PyQt5.QtWebChannel import QWebChannel

# Headless 플래그
HEADLESS = os.environ.get("KU_HEADLESS") == "1"

# QCoreApplication 생성 전 공유 컨텍스트 속성
if not QCoreApplication.testAttribute(Qt.AA_ShareOpenGLContexts):
    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)

# WebEngine은 GUI 모드에서만 임포트
if not HEADLESS:
    from PyQt5.QtWebEngineWidgets import QWebEngineView
else:
    QWebEngineView = None  # placeholder

# QApplication은 GUI 모드에서만 생성
if not HEADLESS:
    _app_guard = QApplication.instance() or QApplication([])
else:
    _app_guard = None

# 외부 라이브러리
import folium

# 경로 설정
HERE = Path(__file__).resolve()             # .../modules/mission_planning/MissionPlanner/main_MP.py
PKG_DIR = HERE.parent                       # .../modules/mission_planning/MissionPlanner
if str(PKG_DIR) not in sys.path:
    sys.path.insert(0, str(PKG_DIR))

# (옵션) 프로젝트 루트 탐지: modules & database 동시 존재 경로
def _detect_project_root() -> Path:
    for p in [HERE] + list(HERE.parents):
        if (p / "modules").exists() and (p / "database").exists():
            return p
    return HERE.parents[4]  # 최후의 가정치(환경에 따라 조정)

_PROJECT_ROOT = _detect_project_root()

# 내부 모듈(※ main_app 의존 제거)
from data_def import (
    mission_helpers as mh,
    d0301, d0302, d0303, d0304,
)
from data_def.mission_helpers import now_ms_since_2000, terrain_elev
from data_def.id_allocator import next_path_id
import corridor_planner as cp
from AnS import run_divide_and_pattern, build_mission_plan_0301

def gui_logger(widget):
    """텍스트 위젯에 실시간 로그를 남기기 위한 래퍼"""
    def _log(msg: str):
        widget.appendPlainText(msg)
        QApplication.processEvents()     # ★ 화면 즉시 갱신
    return _log

def _html_kv(title: str, dic: dict) -> str:
    rows = "\n".join(
        f"<tr><th align='left'>{k}</th><td>{v}</td></tr>"
        for k, v in dic.items()
    )
    return f"<b>{title}</b><br><table>{rows}</table>"

# ════════════════════════════════════════════════════════════════════
class MainGUI(QWidget):
    BRIDGE_THRESH_M = 150.0
    CRUISE_SP       = 40.0

    # ★ 저장 루트: <프로젝트루트>\database
    SAVE_DIR = _PROJECT_ROOT / "database"

    # 하위 폴더들
    DIR_0201 = SAVE_DIR / "InputMissionPlan"
    DIR_0203 = SAVE_DIR / "MissionReferenceInfo"
    DIR_0701 = SAVE_DIR / "MissionPlanOptionInfo"

    def __init__(self) -> None:
        super().__init__()
        # ── 새로운 임무 저장 전에 기존 파일 전체 삭제 ──
        for d in (self.SAVE_DIR, self.DIR_0201, self.DIR_0203):
            d.mkdir(parents=True, exist_ok=True)

        # ── Window ───────────────────────────────────────────────
        self.setWindowTitle("Mission Plan Generator")
        self.resize(1600, 900)

        # ── 내부 상태 ────────────────────────────────────────────
        self.aircraft_pool: list[dict] = []
        self.aircraft_file_path: str | None = None
        self.next_air      = 1
        self.missions:     list[dict] = []
        self.next_im       = 1
        self.pending       = None
        self.pending_pts   = []
        self.flight_plans        = []   # 0303
        self.flight_plans_0304   = []   # 0304
        self.wp_alloc = d0303._WPAllocator()

        self.imp_id_map: dict[int, int] = {}
        self.plan_pkg_id: int | None = None
        self.pkg0201_id = None   # ← 0201 InputMissionPackageID
        self.pkg0203_id = None   # ← 0203 MissionReferencePackageID

        self._visible_aircrafts: set[int] = set(range(1, 7))

        # ── 레이아웃 ────────────────────────────────────────────
        root = QHBoxLayout(self)

        # 지도 영역 ------------------------------------------------
        self.map_frame = QFrame()
        self.map_lay   = QVBoxLayout(self.map_frame)
        root.addWidget(self.map_frame, 2)
        self._build_map()

        # 탭 영역 --------------------------------------------------
        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)
        self._build_tab_initial()
        self._build_tab_0301()
        self._build_tab_0302()
        self._build_tab_0303()
        self._build_tab_0304()

        # ── “plannedMission/임무계획” 기본 탐색 폴더 ─────────────
        base = Path(__file__).resolve().parent       # missionPlanner 디렉터리
        self.default_dir = base / "plannedMission" / "임무계획"
        self.default_dir.mkdir(parents=True, exist_ok=True)

    def _make_option_info_payload(self, mission_plan_id: int, auto_execution: bool = False) -> dict:
        """
        0701 MissionPlanOptionInfo payload 생성 (lower camelCase)
        - 문자열 optionName 제거, 숫자 optionId만 사용.
        - 기본 3옵션(1,4,5)만 생성:
            1: 시스템 추천  → (0,  0,  0)
            4: 정찰특화    → (-1, -1, +1)
            5: 최소시간    → (+1, +1, -1)
        - distance/target 은 지금은 미계산이므로 0으로 모사
        """
        ts = now_ms_since_2000()

        # 효과도(모사값): (survivalRate, timeContraction, recogEffectiveness)
        EFFECTS = {
            1: ( 0,  0,  0),   # 시스템 추천
            4: (-1, -1,  1),   # 정찰특화
            5: ( 1,  1, -1),   # 최소시간
        }

        option_list = []
        for oid in (1, 4, 5):
            sr, tc, reff = EFFECTS[oid]
            option_list.append({
                "optionId": int(oid),                 # ★ 숫자 코드만 기록
                "missionPlanId": int(mission_plan_id),
                "survivalRate": sr,
                "timeContraction": tc,
                "recogEffectiveness": reff,
                "distance": 300000,
                "target": 0
            })

        return {
            "timestamp": ts,
            "source": "MissionPlanner-GUI",
            "autoExecution": bool(auto_execution),
            "optionList": option_list
        }
    
    def _init_save_dirs(self):
        """
        plannedMission/database 하위 필요한 폴더 자동 생성
        (정상 정의된 디렉터리만 생성)
        """
        dirs = [
            self.SAVE_DIR,
            self.DIR_0201,
            self.DIR_0203,
            self.DIR_0701,
            self.SAVE_DIR / "MissionPlan",
            self.SAVE_DIR / "IndividualMissionPlan",
            self.SAVE_DIR / "FlightPath",
        ]
        for p in dirs:
            try:
                p.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                print(f"[WARN] create dir failed: {p} -> {e}")

    # ───────────────────────── 지도 관련 ──────────────────────────
    def _build_map(self):
        if os.environ.get("KU_HEADLESS") == "1":
            return
        self._write_map_html()
        self.map_view = QWebEngineView()
        ch = QWebChannel(self.map_view.page())
        ch.registerObject("bridge", mh.bridge)
        self.map_view.page().setWebChannel(ch)
        self.map_view.setUrl(QUrl.fromLocalFile(os.path.join(os.getcwd(), "map.html")))
        self.map_lay.addWidget(self.map_view)
        mh.bridge.pointClicked.connect(self._handle_point)

    def _rebuild_map(self):
        if os.environ.get("KU_HEADLESS") == "1":
            return
        self._write_map_html()
        self.map_view.reload()

    def _write_map_html(self):
        center = [38.128774, 127.318005]
        fmap   = folium.Map(location=center, zoom_start=14)
        
        _js_links = []

        # 작업 구역(예시 사각형) ---------------------------------
        folium.Rectangle(
            [[38.110432, 127.295620], [38.147111, 127.340401]],
            color="blue", weight=1, fill=True, fill_opacity=0.1
        ).add_to(fmap)

        # ── 0302 개별 임무 도형 ───────────────────────────────
        for miss in self.missions:
            aid   = miss["aircraftID"]
            if aid not in self._visible_aircrafts:   # ★ 가시성 토글
                continue
            info  = miss.get("individualMissionInfo", {})
            color = miss.get("color") or {
                1:"#e6194b", 2:"#3cb44b", 3:"#0082c8",
                4:"#f58231", 5:"#911eb4", 6:"#46f0f0"
            }.get(aid, "gray")

            # ─ 영역(polygons) ---------------------------------
            if info.get("areaList"):
                coords = [(c["latitude"], c["longitude"])
                        for c in info["areaList"][0]["coordinateList"]]
                popup = folium.Popup(
                    _html_kv("Area Mission", {
                        "aircraft": aid,
                        "missionID": miss.get("individualMissionID"),
                        "type": info.get("individualMissionType"),
                        "pattern": info.get("patternType")
                    }), max_width=250)
                folium.Polygon(
                    coords, color=color, weight=2,
                    fill=True, fill_opacity=0.15,
                    popup=popup
                ).add_to(fmap)

            # ─ 통로·선형(lineList) ----------------------------
            elif info.get("lineList"):
                coords = [(c["latitude"], c["longitude"])
                        for c in info["lineList"][0]["coordinateList"]]
                popup = folium.Popup(_html_kv("Corridor", {
                    "aircraft": aid,
                    "width(m)": info["lineList"][0]["width"]
                }), max_width=220)
                folium.PolyLine(
                    coords, color=color, weight=3, dash_array="4,4",
                    popup=popup
                ).add_to(fmap)

            # 3) 이동 / 은엄폐 구분 ----------------------------------
            elif info.get("coordinateList"):
                pts = [(c["latitude"], c["longitude"]) for c in info["coordinateList"]]

                # ── ① 은엄폐( type-9 / pattern-12 ) — 단일 점 ─────────
                if info.get("individualMissionType") == 9 and info.get("patternType") == 12:
                    popup = folium.Popup(
                        _html_kv("Cover-and-Hide", {
                            "aircraft":  aid,
                            "missionID": miss.get("individualMissionID")
                        }), max_width=200)

                    folium.CircleMarker(
                        pts[0], radius=4, color=color, fill=True, fill_opacity=1,
                        popup=popup,
                        tooltip=f"IM {miss['individualMissionID']}"
                    ).add_to(fmap)

                # ── ② 이동( type-7 / pattern-10 ) — 선 + 각 점 ────────
                else:
                    seg_popup = folium.Popup(
                        _html_kv("Move-Route", {
                            "aircraft":  aid,
                            "missionID": miss.get("individualMissionID"),
                            "points":    len(pts)
                        }), max_width=220)

                    folium.PolyLine(
                        pts, color=color, weight=2,
                        popup=seg_popup
                    ).add_to(fmap)

                    for idx, pt in enumerate(pts, 1):
                        wp_popup = folium.Popup(
                            _html_kv(f"WP {idx}", {
                                "lat": f"{pt[0]:.6f}",
                                "lon": f"{pt[1]:.6f}"
                            }), max_width=200)

                        folium.CircleMarker(
                            pt, radius=3, color=color, fill=True, fill_opacity=1,
                            popup=wp_popup,
                            tooltip=f"WP {idx}"
                        ).add_to(fmap)

        # ── 0303 FlightPlan (aircraft 4·5·6) ──────────────────────────────
        COLOR3 = {4: "red", 5: "blue", 6: "brown"}

        for fp in self.flight_plans:                     # ← d0303 결과
            aid = fp["aircraftID"]
            if aid not in self._visible_aircrafts:       # 가시성 토글
                continue
            c = COLOR3.get(aid, "gray")

            # ─ 1) 전체 경로(점선) -------------------------------------------------
            pts = [(w["coordinate"]["latitude"], w["coordinate"]["longitude"])
                for w in fp.get("waypointList", [])]
            line_cls = f"path3_{aid}_{fp['pathID']}"
            if pts:
                folium.PolyLine(
                    pts, color=c, weight=2, dash_array="4,4",
                    **{"className": line_cls}
                ).add_to(fmap)

            # ─ 2) 각 WP + scan-line(모드-2 lineSearch) ----------------------------
            for w in fp.get("waypointList", []):
                wp_id = w["waypointID"]

                popup = folium.Popup(_html_kv(f"WP {wp_id}", {
                            "ETA(ms)": w["eta"],
                            "ECF":     w["ecf"],
                            "speed":   w["speed"],
                        }), max_width=220)

                folium.CircleMarker(
                    [w["coordinate"]["latitude"], w["coordinate"]["longitude"]],
                    radius=3, color=c, fill=True, fill_opacity=1,
                    popup=popup,
                    tooltip=f"WP {wp_id}",
                    **{"className": f"wp_{wp_id}"}
                ).add_to(fmap)

                # 2-B. scan-line(짝지은 좌표 0-1, 2-3, …)
                fp_prop = w.get("filmingProperty", {})
                ls = (fp_prop or {}).get("lineSearch", {})
                coords = ls.get("coordinateList", [])
                for k in range(0, len(coords) - 1, 2):
                    p0, p1 = coords[k], coords[k + 1]
                    p0 = (p0["latitude"], p0["longitude"])
                    p1 = (p1["latitude"], p1["longitude"])

                    ls_cls = f"ls_{aid}_{wp_id}_{k//2}"
                    folium.PolyLine(
                        [p0, p1],
                        color=c, weight=3, opacity=0.9, dash_array="5,4",
                        **{"className": ls_cls}
                    ).add_to(fmap)

                    _js_links.append((wp_id, ls_cls))     # WP ↔ scan-line 매핑

                # 2-C. WP ↔ 전체 경로(path3_) 매핑
                _js_links.append((wp_id, line_cls))

                        
        # ── 0304 시각화 (aircraft 1·2·3) ──────────────────────────────────
        COLOR4 = {1: "green", 2: "orange", 3: "purple"}
        for fp in self.flight_plans_0304:
            aid = fp["aircraftID"]
            if aid not in self._visible_aircrafts:
                continue
            c   = COLOR4.get(aid, "green")

            wps = fp.get("waypointList") or fp.get("lahWaypointList") or []
            if not wps:
                continue

            pts      = [(w["coordinate"]["latitude"], w["coordinate"]["longitude"])
                        for w in wps]
            line_cls = f"path4_{aid}_{fp['pathID']}"
            folium.PolyLine(pts, color=c, weight=2,
                            **{"className": line_cls}).add_to(fmap)

            for w in wps:
                wp_id = w["waypointID"]
                popup = folium.Popup(_html_kv(f"WP {wp_id}", {
                            "ETA(ms)": w.get("eta", 0),
                            "ECF":     w.get("ecf", 0.0),
                            "speed":   w.get("speed", 0.0),
                        }), max_width=220)

                folium.CircleMarker(
                    [w["coordinate"]["latitude"], w["coordinate"]["longitude"]],
                    radius=3, color=c, fill=True, fill_opacity=1,
                    popup=popup,
                    tooltip=f"WP {wp_id}",
                    **{"className": f"wp_{wp_id}"}
                ).add_to(fmap)

                _js_links.append((wp_id, line_cls))     # JS 연동

        # ── HTML 저장 + WebChannel 스크립트 삽입 ───────────────
        path = os.path.join(os.getcwd(), "map.html")
        fmap.save(path)
        js = f"""
    <script src="qrc:///qtwebchannel/qwebchannel.js"></script>
    <script>
    new QWebChannel(qt.webChannelTransport, function(ch){{
        const bridge = ch.objects.bridge;

        /* 1) 지도 객체 */
        let mp = null;
        for (let k in window) {{ if (window[k] instanceof L.Map) {{ mp = window[k]; break; }} }}

        /* 2) WP ↔ Line 클래스 매핑 */
        const rawLinks = {json.dumps(_js_links)};
        const wp2lines = Object.create(null);
        const line2wp  = Object.create(null);
        rawLinks.forEach(([wp, cls]) => {{
            (wp2lines[wp] = wp2lines[wp] || []).push(cls);
            line2wp[cls] = wp;
        }});

        /* 3) 강조 / 해제 */
        function highlight(cls, on) {{
            document.querySelectorAll('.' + cls).forEach(el => {{
                el.style.stroke      = on ? 'yellow' : '';
                el.style.strokeWidth = on ? '4'      : '1';
                el.style.opacity     = on ? '1.0'    : '0.7';
            }});
        }}

        /* 5) 실제 바인드 ---------------------------------------------- */
        function bindClicks() {{
            /* 5-A. WP 마커 */
            Object.keys(wp2lines).forEach(wp => {{
                document.querySelectorAll('.wp_' + wp).forEach(mk => {{
                    mk.onclick = () => activate(wp);
                }});
            }});

            /* 5-B. Line 자체 */
            Object.keys(line2wp).forEach(cls => {{
                document.querySelectorAll('.' + cls).forEach(pl => {{
                    pl.onclick = () => activate(line2wp[cls]);
                }});
            }});
        }}

        /* 6) 맵 레이어가 추가될 때마다 & 첫 렌더 이후 바인드 ------------- */
        if (mp) {{
            mp.whenReady(() => setTimeout(bindClicks, 0));
            mp.on('layeradd',  () => setTimeout(bindClicks, 0));
            mp.on('click', e => bridge.sendPoint(e.latlng.lat, e.latlng.lng));
        }}
    }});
    </script>
    """
        with open(path, "r+", encoding="utf-8") as f:
            html = f.read()
            if "qwebchannel.js" not in html:
                f.seek(0); f.write(html.replace("</body>", js + "</body>")); f.truncate()






    # ─────────────────────────── 탭 0301 ───────────────────────────
    def _build_tab_0301(self):
        tab  = QWidget(); form = QFormLayout(tab)

        # ---- 입력 위젯 -------------------------------------------------
        self.le_mpid  = QLineEdit("")                 # ❯❯ 기본값 공백
        self.le_mpid.setPlaceholderText("auto")       #  ⎯ 자동 부여 안내
        self.le_plid  = QLineEdit("1")
        self.le_ptime = QLineEdit("1.0")

        for lab, w in (("Mission Plan ID:", self.le_mpid),
                       ("Planner ID:",      self.le_plid),
                       ("Planning Time(s):",self.le_ptime)):
            form.addRow(lab, w)

        # ---- 항공기 관리 버튼 ------------------------------------------
        add = QPushButton("Add Aircraft");   add.clicked.connect(self._add_aircraft)
        clr = QPushButton("Clear Aircraft"); clr.clicked.connect(self._clear_aircraft)
        load = QPushButton("Load JSON");     load.clicked.connect(self._load_aircraft_json)
        h = QHBoxLayout(); h.addWidget(add); h.addWidget(clr); h.addWidget(load)
        form.addRow(h)

        # ---- 로그 창 ---------------------------------------------------
        self.log0301 = QTextEdit(); self.log0301.setReadOnly(True)
        form.addRow("Log:", self.log0301)

        self.tabs.addTab(tab, "0301")
        self._refresh_0301()


    def _load_aircraft_json(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Aircraft JSON",
            str(self.default_dir),
            "JSON files (*.json)"
        )
        if not path:
            return

        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)

            # ── 리스트 추출 ────────────────────────────────────
            if isinstance(data, list):
                pool = data
            elif isinstance(data, dict) and "aircraftList" in data:
                pool = data["aircraftList"]
            else:
                raise ValueError(
                    "JSON must be one of\n"
                    "  • [ {\"aircraftID\": …}, … ]\n"
                    "  • { \"aircraftList\": [ … ] }"
                )

            # ── 상태 갱신 ────────────────────────────────────
            self.aircraft_pool      = pool
            self.aircraft_file_path = path
            self.next_air = max((ac["aircraftID"] for ac in pool), default=0) + 1
            self._refresh_air_combo()
            self._refresh_0301()

        except Exception as e:
            QMessageBox.warning(self, "Load Error", str(e))

    def _add_aircraft(self):
        aid = self.next_air; self.next_air = 1 if aid == 6 else aid + 1
        self.aircraft_pool.append({"aircraftID": aid}); self._refresh_0301(); self._refresh_air_combo()

    def _clear_aircraft(self):
        self.aircraft_pool.clear()
        self.aircraft_file_path = None
        self.next_air = 1
        self._refresh_0301()
        self._refresh_air_combo()

    # ─────────────────────────── 초기임무계획 탭 ───────────────────────────
    def _build_tab_initial(self):
        """
        ① 0201 / 0203 JSON 로드 (LED ← 빨강↔초록)
        ② Generate 0301~0304 전 과정 실행
        """
        tab  = QWidget(); form = QFormLayout(tab)

        # 내부 상태 ---------------------------------------------------
        self._cmpk_path = None
        self._mrpk_path = None

        def _led(color: str):
            lbl = QLabel(); lbl.setFixedSize(12, 12)
            lbl.setStyleSheet(f"background:{color}; border-radius:6px")
            return lbl
        self._led_cmpk = _led("#c00")     # red  ← not loaded
        self._led_mrpk = _led("#c00")

        # ------------- Load 0201 ------------------------------------
        btn_cmpk = QPushButton("Load 0201 협업기저임무")
        btn_cmpk.clicked.connect(self._load_0201_json)
        row1 = QHBoxLayout(); row1.addWidget(btn_cmpk); row1.addWidget(self._led_cmpk)
        form.addRow(row1)

        # ------------- Load 0203 ------------------------------------
        btn_mrpk = QPushButton("Load 0203 비행참조정보")
        btn_mrpk.clicked.connect(self._load_0203_json)
        row2 = QHBoxLayout(); row2.addWidget(btn_mrpk); row2.addWidget(self._led_mrpk)
        form.addRow(row2)

        # ------------- Generate All ---------------------------------
        btn_gen = QPushButton("Generate 0301 ~ 0304")
        btn_gen.clicked.connect(self._generate_all)
        form.addRow(btn_gen)

        # ------------- Generate Mission & Options (신규: 생성+저장) ---
        btn_gen_opts = QPushButton("Generate Mission and Options")
        btn_gen_opts.clicked.connect(self._generate_with_options)   # 생성+저장
        form.addRow(btn_gen_opts)

        # -----  가시성 토글 스위치 -----------------------------------
        vis_row = QHBoxLayout()
        self._vis_btns = {}
        for aid, label in [(1,"LAH1"),(2,"LAH2"),(3,"LAH3"),
                        (4,"UAV4"),(5,"UAV5"),(6,"UAV6")]:
            btn = QPushButton(label)
            btn.setCheckable(True); btn.setChecked(True)
            btn.setStyleSheet("QPushButton:checked{background:#4caf50;color:white}"
                            "QPushButton{background:#ddd}")
            btn.toggled.connect(lambda state, a=aid: self._toggle_aircraft(a, state))
            vis_row.addWidget(btn)
            self._vis_btns[aid] = btn
        form.addRow("Show/Hide:", vis_row)

        # ------------- Log window -----------------------------------
        self.log_init = QPlainTextEdit(); self.log_init.setReadOnly(True)
        form.addRow(self.log_init)

        # 탭 0 (맨 왼쪽)에 삽입
        self.tabs.insertTab(0, tab, "초기임무계획")

    def _generate_with_options(self):
        """
        Generate Mission & Options (3세트 보장)
        - 목표 성공 세트 수(target_sets)=3 를 달성할 때까지 시도.
        - 첫 '성공 세트'만 clean 저장, 이후는 누적 저장.
        - 세트 저장 후 missionPlanID를 수집하여,
        최종적으로 0701(MissionPlanOptionInfo/1.json)을 한 파일로 저장.
        """
        import json, time
        from PyQt5.QtWidgets import QMessageBox

        if not (self._cmpk_path and self._mrpk_path):
            QMessageBox.warning(self, "경고", "먼저 0201·0203 JSON을 모두 로드하세요.")
            return

        target_sets    = 3
        max_total_try  = 8
        per_set_retries= 3
        backoff_init_s = 0.4

        success_sets   = 0
        attempts       = 0
        first_clean_done = False
        collected_mp_ids = []

        self.log_init.appendPlainText(f"\n=== Generate Mission & Options: {target_sets} set(s) ===")

        while success_sets < target_sets and attempts < max_total_try:
            set_idx = success_sets + 1
            attempts += 1
            self.log_init.appendPlainText(f"\n--- [SET {set_idx}/{target_sets}] 시작 (attempt {attempts}) ---")
            QApplication.processEvents()

            # 세트 시도 전 버퍼 초기화
            self._reset_generation_buffers()

            ok_this_set = False
            delay = backoff_init_s
            for r in range(1, per_set_retries + 1):
                # 1) 생성(0301→0302→0303/0304)
                self._generate_all()

                # 2) 성공 판정(메모리 상태 점검)
                try:
                    mp_txt  = self.log0301.toPlainText().strip()
                    imp_txt = self.log0302.toPlainText().strip()
                    mp_obj  = json.loads(mp_txt) if mp_txt else {}
                    imp_obj = json.loads(imp_txt) if imp_txt else []
                    has_mp  = bool(mp_obj.get("missionPlanID") or mp_obj.get("MissionPlanID"))
                    has_imp = isinstance(imp_obj, list) and len(imp_obj) > 0
                    has_fp  = (len(self.flight_plans) + len(self.flight_plans_0304)) > 0
                    gen_ok  = has_mp and has_imp and has_fp
                except Exception:
                    gen_ok = False

                if not gen_ok:
                    self.log_init.appendPlainText(
                        f"[WARN] SET {set_idx} 생성 검증 실패 → {delay:.1f}s 대기 후 재시도({r}/{per_set_retries})"
                    )
                    QApplication.processEvents()
                    time.sleep(delay); delay *= 1.8
                    self._reset_generation_buffers()
                    continue

                # 3) 저장 (첫 '성공 세트'만 clean)
                mp_cnt, imp_cnt, fp_cnt, mp_id = self._save_current_set(clean=(not first_clean_done))
                if not first_clean_done:
                    first_clean_done = True

                saved_ok = (mp_cnt == 1) and (imp_cnt > 0) and (fp_cnt > 0) and (mp_id is not None)
                if not saved_ok:
                    self.log_init.appendPlainText(
                        f"[WARN] SET {set_idx} 저장 결과 부족(MP:{mp_cnt}, IMP:{imp_cnt}, FP:{fp_cnt}) → {delay:.1f}s 대기 후 재시도({r}/{per_set_retries})"
                    )
                    QApplication.processEvents()
                    time.sleep(delay); delay *= 1.8
                    self._reset_generation_buffers()
                    continue

                # 4) 성공 처리
                ok_this_set = True
                success_sets += 1
                collected_mp_ids.append(int(mp_id))
                self.log_init.appendPlainText(f"--- [SET {set_idx}/{target_sets}] 완료 (MissionPlanID={mp_id}) ---")
                QApplication.processEvents()
                break

            if not ok_this_set:
                self.log_init.appendPlainText(f"[ERR] SET {set_idx} 생성/저장 실패(모든 재시도 소진). 다음 세트 진행.")
                QApplication.processEvents()

            time.sleep(0.2)  # 세트 간 짧은 휴지

        # === 모든 세트 처리 이후: 0701(MissionPlanOptionInfo) 단일 파일 저장 ===
        if len(collected_mp_ids) >= 1:
            # 요구: 3개 옵션(시스템 추천, 정찰특화, 최소시간). 수집된 ID 수가 3 미만이면 가능한 만큼만 기록.
            if len(collected_mp_ids) < 3:
                self.log0304.appendPlainText(
                    f"[WARN] 0701 옵션 3개 중 {len(collected_mp_ids)}개만 생성됩니다."
                )
            try:
                self._save_option_info_0701(collected_mp_ids[:3], filename="1.json")
            except Exception as e:
                self.log0304.appendPlainText(f"[WARN] 0701 저장 실패: {e}")
        else:
            self.log0304.appendPlainText("[WARN] 0701 저장 생략: MissionPlanID 수집 실패")

        # 요약 알림
        QMessageBox.information(
            self, "완료",
            f"요청 {target_sets}세트 중 {success_sets}세트 생성·저장 완료 (총 시도 {attempts}회)."
        )

    def _reset_generation_buffers(self):
        """세트 생성 재시도 전에 메모리/로그 버퍼를 깨끗하게 초기화한다."""
        try:
            self.missions.clear()
        except Exception:
            self.missions = []
        self.flight_plans = []
        self.flight_plans_0304 = []
        # 텍스트 로그는 다음 생성본으로 덮어쓰게 비워둔다
        if hasattr(self, "log0301"): self.log0301.setPlainText("")
        if hasattr(self, "log0302"): self.log0302.setPlainText("")
        if hasattr(self, "log0303"): self.log0303.setPlainText("")
        
    def _save_current_set(self, clean: bool = False):
        """
        현재 메모리에 올라와 있는 한 세트(0301/0302/0303/0304)를 저장.
        - clean=True  : 저장 전 기존 파일 전체 삭제
        - clean=False : 누적 저장
        반환: (mp_cnt, imp_cnt, fp_cnt, mp_id_int)
        """
        import json, shutil

        # 0) 출력 폴더 준비
        dir_mp   = self.SAVE_DIR / "MissionPlan"
        dir_imp  = self.SAVE_DIR / "IndividualMissionPlan"
        dir_fp   = self.SAVE_DIR / "FlightPath"
        for d in (dir_mp, dir_imp, dir_fp):
            d.mkdir(parents=True, exist_ok=True)

        # 1) (옵션) 기존 파일 정리
        if clean:
            for d in (dir_mp, dir_imp, dir_fp):
                try:
                    removed = 0
                    for p in d.glob("*.json"):
                        try:
                            p.unlink(); removed += 1
                        except Exception as ie:
                            self.log0304.appendPlainText(f"[WARN] 삭제 실패: {p} → {ie}")
                    if removed:
                        self.log0304.appendPlainText(f"[INFO] 기존 임무 정리: {d} ({removed}개 삭제)")
                except Exception as e:
                    self.log0304.appendPlainText(f"[WARN] 기존 파일 정리 실패: {d} → {e}")

        # 2) MissionPlan 1개 저장
        mp_cnt, mp_id_str, mp_id_int = 0, None, None
        try:
            mp_data = json.loads(self.log0301.toPlainText())
            mp_id   = mp_data.get("missionPlanID") or mp_data.get("MissionPlanID")
            mp_id_int = int(mp_id)
            mp_id_str = str(mp_id_int)
            (dir_mp / f"{mp_id_str}.json").write_text(
                json.dumps(mp_data, indent=2, ensure_ascii=False), encoding="utf-8")
            mp_cnt = 1
        except Exception as e:
            self.log0304.appendPlainText(f"[WARN] 0301 저장 실패: {e}")

        # 3) 0302 IMP 여러 개 저장
        imp_cnt = 0
        try:
            for pkg in json.loads(self.log0302.toPlainText()):
                imp_id = str(pkg.get("individualMissionPackageID")
                            or pkg.get("individualMissionPlanPackageID"))
                (dir_imp / f"{imp_id}.json").write_text(
                    json.dumps(pkg, indent=2, ensure_ascii=False), encoding="utf-8")
                imp_cnt += 1
        except Exception as e:
            self.log0304.appendPlainText(f"[WARN] 0302 저장 실패: {e}")

        # 4) 0303 + 0304 FlightPath 저장
        fp_cnt = 0
        for lst in (self.flight_plans, self.flight_plans_0304):
            for fp in lst:
                try:
                    pid = str(fp["pathID"])
                    (dir_fp / f"{pid}.json").write_text(
                        json.dumps(fp, indent=2, ensure_ascii=False), encoding="utf-8")
                    fp_cnt += 1
                except Exception as e:
                    self.log0304.appendPlainText(f"[WARN] PathID {pid} 저장 실패: {e}")

        # 5) 임시 mission_output 폴더 정리(있으면)
        tmp_dir = self.SAVE_DIR / "mission_output"
        try:
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir)
                self.log0304.appendPlainText(f"[INFO] 임시폴더 삭제: {tmp_dir}")
        except Exception as e:
            self.log0304.appendPlainText(f"[WARN] 임시폴더 삭제 실패: {e}")

        # 6) 완료 로그 + 결과 리턴
        self.log0304.appendPlainText(
            f"✔ 세트 저장 완료  →  MissionPlan {mp_cnt}, IndividualMission {imp_cnt}, FlightPath {fp_cnt}"
        )
        return mp_cnt, imp_cnt, fp_cnt, mp_id_int

    def _save_option_info_0701(self, mp_ids: list[int], filename: str = "1.json"):
        """
        0701 MissionPlanOptionInfo 저장(단일 파일)
        - 문자열 optionName 제거, 숫자 optionId만 사용.
        - mp_ids를 순서대로 1(시스템 추천) → 4(정찰특화) → 5(최소시간)에 매핑.
        (부족하면 가능한 개수만 기록)
        """
        import json
        dir_opt = self.SAVE_DIR / "MissionPlanOptionInfo"
        dir_opt.mkdir(parents=True, exist_ok=True)

        EFFECTS = {
            1: ( 0,  0,  0),   # 시스템 추천
            4: (-1, -1,  1),   # 정찰특화
            5: ( 1,  1, -1),   # 최소시간
        }
        code_order = (1, 4, 5)

        opt_list = []
        for i, oid in enumerate(code_order):
            if i >= len(mp_ids): break
            sr, tc, reff = EFFECTS[oid]
            opt_list.append({
                "optionId": int(oid),               # ★ 숫자 코드만
                "missionPlanId": int(mp_ids[i]),
                "survivalRate": sr,
                "timeContraction": tc,
                "recogEffectiveness": reff,
                "distance": 0,
                "target": 0
            })

        payload = {
            "timestamp": now_ms_since_2000(),
            "source": "MOB",
            "autoExecution": False,
            "optionList": opt_list
        }

        out_path = dir_opt / filename
        out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        self.log0304.appendPlainText(f"[INFO] 0701(MissionPlanOptionInfo) 저장 완료 → {out_path}")


    # ─────────────────── 가시성 토글 핸들러 ────────────────────
    def _toggle_aircraft(self, aid: int, state: bool):
        if state:
            self._visible_aircrafts.add(aid)
        else:
            self._visible_aircrafts.discard(aid)
        self._rebuild_map()            # 지도 다시 그리기

    def _generate_all(self):
        if not (self._cmpk_path and self._mrpk_path):
            QMessageBox.warning(self, "경고", "0201·0203 JSON을 모두 로드하세요")
            return

        out_root = self.SAVE_DIR / "mission_output"
        out_root.mkdir(parents=True, exist_ok=True)

        self.log_init.appendPlainText("=== Pipeline 시작 ===")

        # ── 1. 0201+0203 → IMP(0302) ---------------------------------
        try:
            imp_paths = run_divide_and_pattern(
                cmpk_path = self._cmpk_path,
                ref_path  = self._mrpk_path,
                out_dir   = str(out_root),
                log       = gui_logger(self.log_init),   # ★ 변경
            )
            if not imp_paths:
                raise RuntimeError("IMP 생성 결과가 없습니다.")
            self.log_init.appendPlainText(
                f"[OK] IMP {len(imp_paths)} 개 생성 완료")
        except Exception as e:
            self.log_init.appendPlainText(f"[ERR] divide/pattern 실패: {e}")
            return

        # ── 2. MissionPlan 0301 --------------------------------------
        mp_path = out_root / f"MissionPlan_{int(time.time()*1000)}.json"
        try:
            build_mission_plan_0301(
                self._cmpk_path, self._mrpk_path, imp_paths, str(mp_path)
            )

            # ▼ 0301 MissionPlan 에서 aircraftID → individualMissionPackageID 매핑 추출
            with open(mp_path, encoding="utf-8") as f:
                _mp = json.load(f)
            self.imp_id_map = {
                a["aircraftID"]: a["individualMissionPackageID"]
                for a in _mp.get("aircraftList", [])
            }

            self.log_init.appendPlainText(f"[OK] 0301 저장 → {mp_path}")
        except Exception as e:
            self.log_init.appendPlainText(f"[ERR] 0301 생성 실패: {e}")
            return


        # ── 3. IMP 로 GUI self.missions 에 주입 -----------------------
        self.missions.clear()
        max_mid_num = 0
        for imp in imp_paths:
            with open(imp, encoding="utf-8") as f:
                pkg = json.load(f)
            aid = pkg["aircraftID"]
            for im in pkg["individualMissionList"]:
                im["aircraftID"] = aid
                self.missions.append(im)
                try:
                    num = int(im.get("individualMissionID", 0))
                    max_mid_num = max(max_mid_num, num)
                except: pass
        self.next_im = max_mid_num + 1
        self._refresh_0302()          # 기존 함수 재활용 → 0302 로그 창 갱신

        # ── 4. 0303 / 0304 자동 생성(기존 버튼 로직 재사용) ------------
        self._refresh_0303()
        self._refresh_0304()

        # ── 5. 결과 로그 & 0301 텍스트 창 갱신 ------------------------
        self.log_init.appendPlainText(f"[OK] 0301 MissionPlan 저장 → {mp_path}")

        if hasattr(self, "log0301"):                  # 0301 탭이 있으면 표시
            with open(mp_path, encoding="utf-8") as f:
                self.log0301.setPlainText(f.read())

        self.log_init.appendPlainText("=== Pipeline 완료 ===")

        # ▶︎ 모든 기체 표시 상태를 ON 으로 초기화
        self._visible_aircrafts = set(range(1, 7))
        for btn in self._vis_btns.values():
            btn.setChecked(True)
        
    # ─────────────── 0201 / 0203 Load 핸들러 ───────────────
    def _set_led(self, led: QLabel, ok: bool):
        led.setStyleSheet(
            f"background:{'#0c0' if ok else '#c00'}; border-radius:6px")

    # ─────────────────────────────────────────────────────────────
    # 0201 협업기저임무패키지(CMPK) 로드
    #   · 파일명 "1.json" ➜ 1  →  inputMissionPackageID 로 저장
    #   · LED 초록 & 로그 기록
    # ─────────────────────────────────────────────────────────────
    def _load_0201_json(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "0201 CMPK JSON",
            str(self.DIR_0201),
            "JSON files (*.json)",
        )
        if not path:
            return

        try:
            with open(path, encoding="utf-8") as f:
                json.load(f)              # 내용 파싱만 → 형식 오류 검출용
        except Exception as e:
            QMessageBox.warning(self, "0201 로드 실패", str(e))
            return

        try:
            self.pkg0201_id = int(Path(path).stem)   # "123.json" → 123
        except ValueError:
            QMessageBox.warning(self, "0201 로드 실패",
                                "파일 이름이 '정수.json' 형태여야 합니다.")
            return

        self._cmpk_path = path
        self._led_cmpk.setStyleSheet("background:#0c0; border-radius:6px")
        self.log_init.appendPlainText(f"[OK] CMPK loaded  →  {path}")

    # ─────────────────────────────────────────────────────────────
    # 0203 비행참조정보패키지(MRPK) 로드
    #   · 파일명 "3.json" ➜ 3  →  missionReferencePackageID 로 저장
    # ─────────────────────────────────────────────────────────────
    def _load_0203_json(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "0203 MRPK JSON",
            str(self.DIR_0203),
            "JSON files (*.json)",
        )
        if not path:
            return

        try:
            with open(path, encoding="utf-8") as f:
                json.load(f)
        except Exception as e:
            QMessageBox.warning(self, "0203 로드 실패", str(e))
            return

        try:
            self.pkg0203_id = int(Path(path).stem)
        except ValueError:
            QMessageBox.warning(self, "0203 로드 실패",
                                "파일 이름이 '정수.json' 형태여야 합니다.")
            return

        self._mrpk_path = path
        self._led_mrpk.setStyleSheet("background:#0c0; border-radius:6px")
        self.log_init.appendPlainText(f"[OK] MRPK loaded  →  {path}")


    # ─────────────────────────── 탭 0301 갱신 ───────────────────────────
    def _refresh_0301(self):
        # 항공기 없는 경우 안내
        if not self.aircraft_pool:
            self.log0301.setPlainText("➜  먼저 A/C 를 추가하거나 JSON 목록을 불러오세요.")
            return

        # 0201 / 0203 아직 안 불렀다면 중단
        if self.pkg0201_id is None or self.pkg0203_id is None:
            self.log0301.setPlainText("➜  0201·0203 파일을 먼저 불러와야 합니다.")
            return

        # MissionPlanID 입력값 처리
        mpid_raw = self.le_mpid.text().strip()
        mpid = None if mpid_raw == "" else mpid_raw     # str 그대로 — d0301 내부에서 변환

        try:
            msg = d0301.build_mission_plan(
                aircraft_pool               = self.aircraft_pool,
                input_mission_package_id    = self.pkg0201_id,
                mission_reference_package_id= self.pkg0203_id,
                mission_plan_id             = mpid,
                planner_id                  = int(self.le_plid.text() or 0),
                planning_time_s             = float(self.le_ptime.text() or 0),
            )
        except Exception as e:
            QMessageBox.warning(self, "0301 생성 실패", str(e)); return

        # 상태·로그 갱신
        self.plan_pkg_id = msg["aircraftList"][0]["individualMissionPackageID"]
        self.imp_id_map  = {a["aircraftID"]: a["individualMissionPackageID"]
                            for a in msg["aircraftList"]}
        self.log0301.setText(json.dumps(msg, indent=2))


    # ─────────────────────────── 탭 0302 ───────────────────────────
    def _build_tab_0302(self):
        tab = QWidget(); form = QFormLayout(tab)

        # ── 항공기 선택 콤보 ───────────────────────────────────
        self.cmb_air = QComboBox()
        self._refresh_air_combo()
        form.addRow("Aircraft ID:", self.cmb_air)

        # ── 버튼들 ─────────────────────────────────────────────
        new  = QPushButton("New Mission")       # 수동 추가
        new.clicked.connect(self._new_mission)

        clr  = QPushButton("Clear Missions")    # 전체 삭제
        clr.clicked.connect(self._clear_missions)

        load = QPushButton("Load 0302 JSON(s)") # 여러 개 불러오기
        load.clicked.connect(self._load_0302_jsons)

        h = QHBoxLayout()
        for b in (new, clr, load): h.addWidget(b)
        form.addRow(h)

        # ── 로그창 ─────────────────────────────────────────────
        self.log0302 = QTextEdit(); self.log0302.setReadOnly(True)
        form.addRow("Log:", self.log0302)

        self.tabs.addTab(tab, "0302")
        self._refresh_0302()

    def _load_0302_jsons(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Select 0302 JSON files",
            str(self.default_dir),
            "JSON files (*.json)"
        )
        if not paths:
            return

        try:
            self.missions.clear()
            max_mid_num = 0

            for p in paths:
                with open(p, encoding="utf-8") as f:
                    pkg = json.load(f)

                if ("aircraftID" not in pkg or
                    "individualMissionList" not in pkg):
                    raise ValueError(f"{os.path.basename(p)}: invalid 0302 format")

                aid = pkg["aircraftID"]
                for im in pkg["individualMissionList"]:
                    im_cp = dict(im)
                    im_cp["aircraftID"] = aid
                    self.missions.append(im_cp)

                    # ── ID 숫자 부분만 추출해 비교 ──────────────
                    iid_raw = im_cp.get("individualMissionID", 0)
                    try:
                        iid_num = int(iid_raw)
                    except (ValueError, TypeError):
                        iid_num = 0                     # 문자열·None → 0
                    max_mid_num = max(max_mid_num, iid_num)

            self.next_im = max_mid_num + 1
            self._refresh_0302()
            self._rebuild_map()
            QMessageBox.information(
                self, "Load Complete",
                f"Loaded {len(paths)} file(s), total {len(self.missions)} missions.")
        except Exception as e:
            QMessageBox.warning(self, "Load Error", str(e))

    def _refresh_air_combo(self):
        self.cmb_air.clear(); self.cmb_air.addItems([str(a["aircraftID"]) for a in self.aircraft_pool])

    def _new_mission(self):
        if not self.cmb_air.currentText(): return
        dlg = mh.MissionMetaDialog(self.next_im, self)
        if dlg.exec_() == QDialog.Accepted:
            self.pending = dlg.get_result(); self.pending_pts = []
            typ, need, _ = self.pending; self.log0302.append(f"Select {need} points (type {typ})")

    def _clear_missions(self):
        self.missions.clear(); self.next_im = 1; self._refresh_0302(); self._rebuild_map()

    def _refresh_0302(self):
        pkg_list = d0302.build_mission_packages(
            self.missions,                 # IM 원본 리스트
            cmpk_id      = self.pkg0201_id,  # 0201 파일명 숫자
            plan_pkg_map = self.imp_id_map,  # aircraftID → IMP ID
        )
        self.log0302.setText(json.dumps(pkg_list, indent=2, ensure_ascii=False))
        self._rebuild_map()



    # ─────────────────────────── 탭 0303 ───────────────────────────
    def _build_tab_0303(self):
        tab = QWidget(); lay = QVBoxLayout(tab)
        gen = QPushButton("Generate 0303 FlightPlan"); gen.clicked.connect(self._refresh_0303)
        self.log0303 = QPlainTextEdit(); self.log0303.setReadOnly(True)
        lay.addWidget(gen); lay.addWidget(self.log0303); self.tabs.addTab(tab, "0303")

    def _refresh_0303(self):
        fp = d0303.build_flight_plans(self.missions, self.wp_alloc, self.CRUISE_SP, turn_step_deg=15.0)
        self.flight_plans = fp.copy()
        self.log0303.setPlainText(json.dumps(fp, indent=2, ensure_ascii=False))
        self._rebuild_map()

    # ─────────────────────────── 탭 0304 ───────────────────────────
    def _build_tab_0304(self):
        tab = QWidget(); lay = QVBoxLayout(tab)

        # ── 생성 모드 선택 ───────────────────────────────
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["100 m 분할 (기본)", "RL 모델 사용"])
        lay.addWidget(self.cmb_mode)

        # ── (RL 전용) 모델·VecNorm 경로 입력 ─────────────
        form = QFormLayout()
        self.le_model   = QLineEdit(r"models\lah_model.zip")
        self.le_vecnorm = QLineEdit(r"models\lah_model.pkl")
        form.addRow("PPO Model (.zip):",   self.le_model)
        form.addRow("VecNormalize (.pkl):", self.le_vecnorm)
        lay.addLayout(form)

        # ── 버튼 영역 ───────────────────────────────────
        btn_gen  = QPushButton("Generate 0304 FlightPlan")
        btn_gen.clicked.connect(self._refresh_0304)

        btn_save = QPushButton("Save Missions")
        btn_save.clicked.connect(self._save_all_missions)

        btn_check = QPushButton("Check Missions")      # ★ 새 버튼
        btn_check.clicked.connect(self._check_missions)

        h_btn = QHBoxLayout()
        for b in (btn_gen, btn_save, btn_check):
            h_btn.addWidget(b)
        lay.addLayout(h_btn)

        # ── 로그창 ─────────────────────────────────────
        self.log0304 = QPlainTextEdit(); self.log0304.setReadOnly(True)
        lay.addWidget(self.log0304)

        self.tabs.addTab(tab, "0304")

    def _check_missions(self, check_saved: bool = True):
        """
        0201‧0203‧0301‧0302‧0303‧0304 (메모리) + 디스크 저장본
        모두를 한 번에 검증:
        • 0301 ↔ 0302: aircraftID별 IMP ID 일치(개수/대응 포함)
        • 0302 ↔ 0303/0304: pathID→aircraftID 매칭, 모든 pathID가 FlightPath로 생성됐는지
        • waypointList / lahWaypointList 모두 지원
        • 0303(UAV) filmingProperty 필수 필드, 0304(LAH)는 스킵
        • WP ID 중복/ECF 단조 증가/nextWaypointID 체인
        """
        import json, numbers, math
        from pathlib import Path
        from PyQt5.QtWidgets import QMessageBox

        self.log0304.appendPlainText("\n===== CHECK MISSIONS =====")
        errors, warns, oks = [], [], []

        # ───────────────────────── 공통 헬퍼 ─────────────────────────
        def _get_wps(fp: dict) -> list:
            """0303(UAV)·0304(LAH) 모두 호환: waypointList / lahWaypointList 지원"""
            return fp.get("waypointList") or fp.get("lahWaypointList") or []

        def _check_json_types(imp_pkgs: list, tag: str):
            """0302 타입 보정 확인: isDone/isHole/altitude"""
            local_errs = 0
            for pkg in imp_pkgs:
                for im in pkg.get("individualMissionList", []):
                    mid = im.get("individualMissionID", "?")
                    if not isinstance(im.get("isDone"), bool):
                        errors.append(f"{tag} mid={mid}: isDone must be bool")
                        local_errs += 1
                    info = im.get("individualMissionInfo", {})
                    for area in info.get("areaList", []):
                        if "isHole" in area and not isinstance(area["isHole"], bool):
                            errors.append(f"{tag} mid={mid}: isHole must be bool")
                            local_errs += 1
                    blocks = info.get("areaList") or info.get("lineList") or []
                    for blk in blocks:
                        for p in blk.get("coordinateList", []):
                            alt = p.get("altitude")
                            if alt is not None and (not isinstance(alt, numbers.Real) or math.isnan(alt)):
                                errors.append(f"{tag} mid={mid}: altitude must be number")
                                local_errs += 1
            return local_errs

        def _check_fps(fp_list: list, missions_src: list, tag: str, strict_mode_check: bool = True):
            """
            FlightPath 기본 검사 + (옵션) filmingProperty 검사
            · WP 중복, ECF 단조 증가, nextWaypointID 체인
            · strict_mode_check=True이면 0303(UAV) filmingProperty 필수 필드 검사
            """
            local_errs, local_warns = 0, 0
            wp_global = set()
            miss_path_ids = {im["pathID"] for im in missions_src}

            for fp in fp_list:
                path_id = fp.get("pathID")
                aid     = fp.get("aircraftID")

                wps = _get_wps(fp)
                if not wps:
                    errors.append(f"{tag} pathID {path_id}: no waypoints (waypointList/lahWaypointList empty)")
                    local_errs += 1
                    continue

                # 0302와 pathID 매칭
                if path_id not in miss_path_ids:
                    errors.append(f"{tag} pathID {path_id} not found in 0302 missions")
                    local_errs += 1

                # waypointID 중복 및 ECF 단조 증가
                last_ecf = -1.0
                for wp in wps:
                    wid = wp.get("waypointID")
                    if wid in wp_global:
                        errors.append(f"{tag} duplicate waypointID {wid}")
                        local_errs += 1
                    wp_global.add(wid)

                    ecf = wp.get("ecf", -1.0)
                    if ecf + 1e-6 < last_ecf:
                        errors.append(f"{tag} waypointID {wid}: ECF not increasing")
                        local_errs += 1
                    last_ecf = ecf

                    # ── 0303(UAV)만 filmingProperty 검사 ──
                    if strict_mode_check:
                        fp_prop = wp.get("filmingProperty", {})
                        mode    = fp_prop.get("operationMode", 0)
                        need_top = {
                            1: ["coordinateOrientation"],
                            2: ["lineSearch"],
                            3: ["autoTracking"],
                            4: ["aircraftFixed"],   # HOLD
                            5: ["autoScan"],
                        }.get(mode, [])
                        for f in need_top:
                            if f not in fp_prop:
                                errors.append(f"{tag} WP {wid}: mode-{mode} needs {f}")
                                local_errs += 1
                        if mode == 4 and "aircraftFixed" in fp_prop:
                            af = fp_prop["aircraftFixed"]
                            for sub in ("GimbalPitch", "GimbalYaw"):
                                if sub not in af:
                                    errors.append(f"{tag} WP {wid}: aircraftFixed missing {sub}")
                                    local_errs += 1

                # nextWaypointID 체인 검증
                chain = {w.get("waypointID"): w.get("nextWaypointID") for w in wps if "waypointID" in w}
                visited, cur = set(), wps[0].get("waypointID")
                while cur and cur not in visited:
                    visited.add(cur)
                    cur = chain.get(cur, 0)
                if len(visited) != len(wps):
                    local_warns += 1
                    warns.append(f"{tag} pathID {path_id}: nextWaypointID chain broken")

            if local_errs == 0:
                oks.append(f"{tag}: FlightPath OK ({len(fp_list)} paths)")
            return local_errs, local_warns

        # ───────────────────── 1) CMPK / MRPK 파일 로드 ─────────────────────
        for _tag, _path in (("0201", self._cmpk_path), ("0203", self._mrpk_path)):
            try:
                with open(_path, encoding="utf-8") as f: json.load(f)
                oks.append(f"{_tag}: file loaded OK")
            except Exception as e:
                errors.append(f"{_tag} validation failed - {e}")

        # ───────────────────── 2) 메모리-상 0301/0302 로딩 ─────────────────────
        # 0301
        try:
            mp_mem = json.loads(self.log0301.toPlainText())
            d0301._validate_mission_plan(mp_mem)
            oks.append("MEM_0301: MissionPlan OK")
        except Exception as e:
            errors.append(f"MEM_0301 validation failed - {e}")
            mp_mem = None

        # 0302
        try:
            imp_mem = json.loads(self.log0302.toPlainText())
            cmpk_id = self.pkg0201_id or 0
            d0302._validate_mission_packages(imp_mem, self.imp_id_map, cmpk_id)
            _check_json_types(imp_mem, "MEM_0302")
            oks.append("MEM_0302: IndividualMissionPlan OK")
        except Exception as e:
            errors.append(f"MEM_0302 validation failed - {e}")
            imp_mem = []

        # ── 0301 ↔ 0302: IMP ID 맵핑 일치 검사 (메모리) ──────────────────────
        try:
            if mp_mem:
                plan_pkg_map_mem = {a["aircraftID"]: a["individualMissionPackageID"]
                                    for a in mp_mem.get("aircraftList", [])}
                imp_pkg_by_aid_mem = {pkg["aircraftID"]: pkg["individualMissionPackageID"]
                                    for pkg in imp_mem}

                # A) 0301에 있는 모든 항공기가 0302에도 동일 IMP ID로 존재?
                for aid, imp_id in plan_pkg_map_mem.items():
                    if imp_pkg_by_aid_mem.get(aid) != imp_id:
                        errors.append(f"MEM_IDLINK: A/C {aid} IMP ID mismatch (0301={imp_id}, 0302={imp_pkg_by_aid_mem.get(aid)})")

                # B) 0302에 있는 모든 항공기가 0301에도 동일 IMP ID로 존재?
                for aid, imp_id in imp_pkg_by_aid_mem.items():
                    if plan_pkg_map_mem.get(aid) != imp_id:
                        errors.append(f"MEM_IDLINK: A/C {aid} IMP ID mismatch (0302={imp_id}, 0301={plan_pkg_map_mem.get(aid)})")

                if not any(s.startswith("MEM_IDLINK") for s in errors):
                    oks.append("MEM_IDLINK: 0301↔0302 IMP ID matched for all aircraft")
        except Exception as e:
            errors.append(f"MEM_IDLINK check failed - {e}")

        # ── 0302 ↔ 0303/0304: pathID→aircraftID 매핑 검사 (메모리) ─────────────
        # 0302에서 pathID→A/C 매핑 생성
        path_to_aid_mem = {}
        try:
            for pkg in imp_mem:
                aid = pkg.get("aircraftID")
                for im in pkg.get("individualMissionList", []):
                    pid = im.get("pathID")
                    if pid is None: 
                        errors.append(f"MEM_0302: mission has no pathID (A/C {aid})")
                        continue
                    prev = path_to_aid_mem.get(pid)
                    if prev is not None and prev != aid:
                        errors.append(f"MEM_0302: pathID {pid} appears under multiple aircraft ({prev} vs {aid})")
                    path_to_aid_mem[pid] = aid
            if path_to_aid_mem:
                oks.append(f"MEM_0302: {len(path_to_aid_mem)} pathID collected")
        except Exception as e:
            errors.append(f"MEM_0302 pathID map failed - {e}")

        # 0303/0304 메모리 상 FlightPath 전부 합쳐 검사
        fps_mem_all = list(self.flight_plans or []) + list(self.flight_plans_0304 or [])
        seen_paths_mem = set()
        try:
            # A) 기본 FlightPath 품질검사 (0303은 strict, 0304는 non-strict)
            fp_uav = [fp for fp in fps_mem_all if fp.get("aircraftID") in (4,5,6)]
            fp_lah = [fp for fp in fps_mem_all if fp.get("aircraftID") in (1,2,3)]
            _check_fps(fp_uav, self.missions, "MEM_0303", strict_mode_check=True)
            _check_fps(fp_lah, self.missions, "MEM_0304", strict_mode_check=False)

            # B) pathID→A/C 정확히 매칭되는지
            for fp in fps_mem_all:
                pid = fp.get("pathID")
                aid = fp.get("aircraftID")
                if pid not in path_to_aid_mem:
                    errors.append(f"MEM_IDLINK: FlightPath pathID {pid} not found in MEM_0302")
                    continue
                expect_aid = path_to_aid_mem[pid]
                if expect_aid != aid:
                    errors.append(f"MEM_IDLINK: pathID {pid} aircraft mismatch (0302={expect_aid}, FP={aid})")
                seen_paths_mem.add(pid)

            # C) 0302에 있었는데 FlightPath가 안 만들어진 pathID 찾기
            missing = set(path_to_aid_mem.keys()) - seen_paths_mem
            if missing:
                warns.append(f"MEM_IDLINK: {len(missing)} pathID missing in FlightPath (e.g., {sorted(list(missing))[:6]}...)")
            else:
                oks.append("MEM_IDLINK: All pathID(s) in 0302 have FlightPath")
        except Exception as e:
            errors.append(f"MEM_IDLINK FlightPath check failed - {e}")

        # ───────────────────── 3) 디스크 저장본 (옵션) ─────────────────────
        if check_saved:
            dir_mp  = self.SAVE_DIR / "MissionPlan"
            dir_imp = self.SAVE_DIR / "IndividualMissionPlan"
            dir_fp  = self.SAVE_DIR / "FlightPath"

            # 3-A. MissionPlan
            mp_disk_latest = None
            try:
                for p in sorted(dir_mp.glob("*.json")):
                    with p.open(encoding="utf-8") as f: mp = json.load(f)
                    d0301._validate_mission_plan(mp)
                    oks.append(f"DISK_0301 {p.name}: OK")
                mp_disk_latest = max(dir_mp.glob("*.json"), default=None, key=lambda p: p.stat().st_mtime)
            except Exception as e:
                errors.append(f"DISK_0301 validation failed - {e}")

            # 3-B. IMP + missions 집계
            imp_pkgs_disk, missions_disk = [], []
            plan_pkg_map_disk = {}
            try:
                if mp_disk_latest:
                    with mp_disk_latest.open(encoding="utf-8") as f:
                        _lmp = json.load(f)
                    plan_pkg_map_disk = {a["aircraftID"]: a["individualMissionPackageID"]
                                        for a in _lmp.get("aircraftList", [])}
                for p in sorted(dir_imp.glob("*.json")):
                    with p.open(encoding="utf-8") as f: pkg = json.load(f)
                    imp_pkgs_disk.append(pkg)
                    aid = pkg["aircraftID"]
                    for im in pkg.get("individualMissionList", []):
                        im_cp = dict(im); im_cp["aircraftID"] = aid
                        missions_disk.append(im_cp)

                if imp_pkgs_disk:
                    cmpk_id = self.pkg0201_id or 0
                    d0302._validate_mission_packages(imp_pkgs_disk, plan_pkg_map_disk, cmpk_id)
                    oks.append(f"DISK_0302 {len(imp_pkgs_disk)} pkg: OK")
            except Exception as e:
                errors.append(f"DISK_0302 packages: {e}")

            # ── 0301 ↔ 0302: IMP ID 맵핑 일치 검사 (디스크) ──────────────────
            try:
                imp_pkg_by_aid_disk = {pkg["aircraftID"]: pkg["individualMissionPackageID"]
                                    for pkg in imp_pkgs_disk}
                for aid, imp_id in plan_pkg_map_disk.items():
                    if imp_pkg_by_aid_disk.get(aid) != imp_id:
                        errors.append(f"DISK_IDLINK: A/C {aid} IMP ID mismatch (0301={imp_id}, 0302={imp_pkg_by_aid_disk.get(aid)})")
                for aid, imp_id in imp_pkg_by_aid_disk.items():
                    if plan_pkg_map_disk.get(aid) != imp_id:
                        errors.append(f"DISK_IDLINK: A/C {aid} IMP ID mismatch (0302={imp_id}, 0301={plan_pkg_map_disk.get(aid)})")
                if plan_pkg_map_disk and imp_pkg_by_aid_disk and not any(s.startswith("DISK_IDLINK") for s in errors):
                    oks.append("DISK_IDLINK: 0301↔0302 IMP ID matched for all aircraft")
            except Exception as e:
                errors.append(f"DISK_IDLINK check failed - {e}")

            # 3-C. FlightPath(디스크)
            fp_disk = []
            try:
                for p in dir_fp.glob("*.json"):
                    with p.open(encoding="utf-8") as f: fp_disk.append(json.load(f))
                # 기본 품질검사
                fp_uav_d = [fp for fp in fp_disk if fp.get("aircraftID") in (4,5,6)]
                fp_lah_d = [fp for fp in fp_disk if fp.get("aircraftID") in (1,2,3)]
                _check_fps(fp_uav_d, missions_disk, "DISK_FP", strict_mode_check=True)
                _check_fps(fp_lah_d, missions_disk, "DISK_FP", strict_mode_check=False)

                # pathID ↔ A/C 매핑 검사
                path_to_aid_disk = {}
                for pkg in imp_pkgs_disk:
                    aid = pkg.get("aircraftID")
                    for im in pkg.get("individualMissionList", []):
                        pid = im.get("pathID")
                        if pid is not None:
                            prev = path_to_aid_disk.get(pid)
                            if prev is not None and prev != aid:
                                errors.append(f"DISK_0302: pathID {pid} appears under multiple aircraft ({prev} vs {aid})")
                            path_to_aid_disk[pid] = aid

                seen_paths_disk = set()
                for fp in fp_disk:
                    pid = fp.get("pathID")
                    aid = fp.get("aircraftID")
                    if pid not in path_to_aid_disk:
                        errors.append(f"DISK_IDLINK: FlightPath pathID {pid} not found in 0302")
                        continue
                    expect_aid = path_to_aid_disk[pid]
                    if expect_aid != aid:
                        errors.append(f"DISK_IDLINK: pathID {pid} aircraft mismatch (0302={expect_aid}, FP={aid})")
                    seen_paths_disk.add(pid)

                missing_disk = set(path_to_aid_disk.keys()) - seen_paths_disk
                if missing_disk:
                    warns.append(f"DISK_IDLINK: {len(missing_disk)} pathID missing in FlightPath (e.g., {sorted(list(missing_disk))[:6]}...)")
                else:
                    if path_to_aid_disk:
                        oks.append("DISK_IDLINK: All pathID(s) in 0302 have FlightPath")
            except Exception as e:
                errors.append(f"DISK_IDLINK FlightPath check failed - {e}")

        # ───────────────────── 4) 로그 출력 ─────────────────────
        for line in oks:   self.log0304.appendPlainText(f"[OK  ] {line}")
        for w in warns:    self.log0304.appendPlainText(f"[WARN] {w}")
        for e in errors:   self.log0304.appendPlainText(f"[ERR ] {e}")

        if errors:
            QMessageBox.critical(self, "Check Missions",
                                f"{len(errors)} error(s) • {len(warns)} warning(s)")
        elif warns:
            QMessageBox.warning(self, "Check Missions",
                                f"All critical tests passed with {len(warns)} warning(s).")
        else:
            QMessageBox.information(self, "Check Missions", "All checks passed!")





    def _refresh_0304(self):
        mode = self.cmb_mode.currentText()

        if mode.startswith("100"):
            fp = d0304.build_lah_flight_plans_fixed(
                self.missions,
                cruise_speed = self.CRUISE_SP,
                wp_alloc     = self.wp_alloc,
            )
        else:
            model_path   = self.le_model.text().strip()
            vecnorm_path = self.le_vecnorm.text().strip() or None
            fp = d4rl.build_lah_flight_plans_rl(
                self.missions,
                model_path   = model_path,
                vecnorm_path = vecnorm_path,
                cruise_speed = self.CRUISE_SP,
                wp_alloc     = self.wp_alloc,
            )

        self.flight_plans_0304 = fp
        self.log0304.setPlainText(json.dumps(fp, indent=2, ensure_ascii=False))
        self._rebuild_map()

    # ─────────────────── 공통 핸들러 / 유틸 ────────────────────
    def _handle_point(self, lat: float, lon: float):
        if not self.pending:
            return
        typ, need, width = self.pending
        alt = terrain_elev(lat, lon) + 200.0
        self.pending_pts.append({"latitude": lat,
                                "longitude": lon,
                                "altitude": int(round(alt))})   # ← int 처리로 변경
        self.map_view.page().runJavaScript(
            f"(function(){{var m=null;for(var k in window)if(window[k] instanceof L.Map){{m=window[k];break;}}"
            f"if(m)L.circleMarker([{lat},{lon}],{{radius:4,color:'red',fill:true}}).addTo(m);}})();"
        )
        cur = len(self.pending_pts)
        self.log0302.append(f"Point {cur}/{need} selected")
        if cur == need:
            self._save_pending()

    def _save_pending(self):
        if not self.pending:
            return

        # ── 내부 상태 --------------------------------------------------
        typ, _, width = self.pending          # typ: 0-Area, 1-Corridor, 2-Move
        mid   = self.next_im
        aid   = int(self.cmb_air.currentText())

        miss = mh.make_individual_mission(mid)
        miss["aircraftID"] = aid
        miss["pathID"]     = next_path_id(aid)

        # 0301 Plan Package ID 연결
        if self.plan_pkg_id is not None:
            miss["individualMissionPlanPackageID"] = self.plan_pkg_id

        # ── IM-Type / Pattern Type 매핑 -------------------------------
        #   0:Area → 3/0,   1:Corridor → 6/4,   2:Move → 7/0
        TYPE_MAP = {0: (3, 0), 1: (6, 4), 2: (7, 0)}
        im_type, pat_type = TYPE_MAP[typ]

        info = miss["individualMissionInfo"]
        info["individualMissionType"] = im_type
        info["patternType"]           = pat_type

        # ── 좌표 저장 --------------------------------------------------
        if typ == 0:                              # Area (polygon)
            info["areaList"] = [{
                "isHole": False,
                "coordinateList": self.pending_pts
            }]
        elif typ == 1:                            # Corridor (lineList)
            info["lineList"] = [{
                "width": width,
                "coordinateList": self.pending_pts
            }]
        else:                                     # Move (coordinateList)
            info["coordinateList"] = self.pending_pts

        # ── 목록 반영 & UI 갱신 ----------------------------------------
        self.missions.append(miss)
        self.next_im += 1
        self.pending, self.pending_pts = None, []
        self.log0302.append("✔ Mission saved")
        self._refresh_0302()
        self._rebuild_map()


    def _save_all_missions(self):
        """
        • 저장 폴더: SAVE_DIR/database 하위(구성에 따라) 또는 SAVE_DIR 하위
        - MissionPlan/<MissionPlanID>.json
        - IndividualMissionPlan/<IMP_ID>.json
        - FlightPath/<PathID>.json
        • 새로운 임무 저장 전, 위 3개 폴더의 기존 *.json 전부 삭제(클린 세이브)
        • Save 후 mission_output 임시폴더 자동 삭제
        """
        import json, shutil

        # ── 1) 최종 저장 폴더 준비 ─────────────────────────────
        dir_mp  = self.SAVE_DIR / "MissionPlan"
        dir_imp = self.SAVE_DIR / "IndividualMissionPlan"
        dir_fp  = self.SAVE_DIR / "FlightPath"
        for d in (dir_mp, dir_imp, dir_fp):
            d.mkdir(parents=True, exist_ok=True)

        # ── 2) 기존 임무 파일 전부 삭제(클린 세이브) ────────────
        for d in (dir_mp, dir_imp, dir_fp):
            try:
                removed = 0
                for p in d.glob("*.json"):
                    try:
                        p.unlink()
                        removed += 1
                    except Exception as ie:
                        self.log0304.appendPlainText(f"[WARN] 삭제 실패: {p} → {ie}")
                if removed:
                    self.log0304.appendPlainText(f"[INFO] 기존 임무 정리: {d} ({removed}개 삭제)")
            except Exception as e:
                self.log0304.appendPlainText(f"[WARN] 기존 파일 정리 실패: {d} → {e}")

        # ── 3) 0301 MissionPlan 1개 저장 ─────────────────────
        try:
            mp_data = json.loads(self.log0301.toPlainText())
            mp_id   = str(mp_data.get("missionPlanID") or mp_data.get("MissionPlanID"))
            (dir_mp / f"{mp_id}.json").write_text(
                json.dumps(mp_data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            self.log0304.appendPlainText(f"[WARN] 0301 저장 실패: {e}")

        # ── 4) 0302 IndividualMissionPlan 여러 개 저장 ───────
        imp_cnt = 0
        try:
            for pkg in json.loads(self.log0302.toPlainText()):
                imp_id = str(pkg.get("individualMissionPackageID")
                            or pkg.get("individualMissionPlanPackageID"))
                (dir_imp / f"{imp_id}.json").write_text(
                    json.dumps(pkg, indent=2, ensure_ascii=False), encoding="utf-8")
                imp_cnt += 1
        except Exception as e:
            self.log0304.appendPlainText(f"[WARN] 0302 저장 실패: {e}")

        # ── 5) 0303‧0304 FlightPath 저장 ─────────────────────
        fp_cnt = 0
        for lst in (self.flight_plans, self.flight_plans_0304):
            for fp in lst:
                try:
                    pid = str(fp["pathID"])
                    (dir_fp / f"{pid}.json").write_text(
                        json.dumps(fp, indent=2, ensure_ascii=False), encoding="utf-8")
                    fp_cnt += 1
                except Exception as e:
                    self.log0304.appendPlainText(f"[WARN] PathID {pid} 저장 실패: {e}")

        # ── 6) 임시 mission_output 폴더 자동 삭제 ─────────────
        tmp_dir = self.SAVE_DIR / "mission_output"
        try:
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir)
                self.log0304.appendPlainText(f"[INFO] 임시폴더 삭제: {tmp_dir}")
        except Exception as e:
            self.log0304.appendPlainText(f"[WARN] 임시폴더 삭제 실패: {e}")

        # ── 7) 완료 로그 ─────────────────────────────────────
        self.log0304.appendPlainText(
            f"✔ 저장 완료  →  MissionPlan 1, IndividualMission {imp_cnt}, FlightPath {fp_cnt}"
        )

# ===== [ADD] Dashboard에서 GUI 없이 호출할 수 있는 헤드리스 엔트리포인트 =====
from typing import Optional, List, Tuple, Dict, Any

def _pick_first_json(d: Path) -> Optional[Path]:
    try:
        return sorted([p for p in d.glob("*.json") if p.is_file()])[0]
    except Exception:
        return None

def _imp_path_id(im: dict) -> Optional[int]:
    # 0302 IM 원본에서 pathID 후보 키들을 폭넓게 수용
    for k in ("pathID","pathId","individualMissionPathID","missionPathID"):
        v = im.get(k)
        try:
            if v is not None:
                return int(v)
        except Exception:
            pass
    mi = im.get("missionInfo") or im.get("individualMissionInfo")
    if isinstance(mi, dict):
        for k in ("pathID","pathId"):
            v = mi.get(k)
            try:
                if v is not None:
                    return int(v)
            except Exception:
                pass
    return None

def _headless_generate_and_save_one_set(cmpk_path: str, mrpk_path: str, db_root: str, clean: bool) -> int:
    """
    0201+0203 → 0302 → 0301 → 0303/0304까지 생성하여
    <db_root> 하위(MissionPlan / IndividualMissionPlan / FlightPath)에 저장.
    성공 시 missionPlanID(int) 반환. 실패 시 예외 발생.
    """
    import json, time, shutil

    out_root = Path(db_root) / "mission_output"
    out_root.mkdir(parents=True, exist_ok=True)

    # 1) 0201+0203 → IMP(0302)
    imp_paths = run_divide_and_pattern(
        cmpk_path=str(cmpk_path),
        ref_path=str(mrpk_path),
        out_dir=str(out_root),
        log=lambda m: None  # 대시보드가 로그를 가져가므로 여기선 묵음
    )
    if not imp_paths:
        raise RuntimeError("IMP 생성 결과가 없습니다.")

    # 2) 0301 MissionPlan 생성
    mp_path = out_root / f"MissionPlan_{int(time.time()*1000)}.json"
    build_mission_plan_0301(str(cmpk_path), str(mrpk_path), imp_paths, str(mp_path))
    with mp_path.open(encoding="utf-8") as f:
        mp_json = json.load(f)
    imp_id_map = {a["aircraftID"]: a["individualMissionPackageID"] for a in mp_json.get("aircraftList", [])}

    # 3) missions 집계 + pathID 매핑(0302/0303/0304 일치 보장)
    missions: List[dict] = []
    pid_map: Dict[Tuple[int,int], int] = {}   # (aircraftID, individualMissionID) -> pathID

    for imp in imp_paths:
        with open(imp, encoding="utf-8") as f:
            pkg = json.load(f)
        aid = int(pkg["aircraftID"])
        for im in pkg.get("individualMissionList", []):
            im2 = dict(im); im2["aircraftID"] = aid
            if "individualMissionPlanPackageID" not in im2 and imp_id_map:
                im2["individualMissionPlanPackageID"] = imp_id_map.get(aid)

            mid = int(im2.get("individualMissionID", 0))
            if aid in (1,2,3):  # LAH: 신규 pathID 발급
                pid = int(next_path_id(aid))
                im2["pathID"] = pid
                pid_map[(aid, mid)] = pid
            else:               # UAV: IMP의 pathID 유지
                imp_pid = _imp_path_id(im2)
                if imp_pid is not None:
                    im2["pathID"] = int(imp_pid)
                    pid_map[(aid, mid)] = int(imp_pid)

            missions.append(im2)

    # 4) 0303/0304 생성
    manned_missions = [im for im in missions if int(im.get("aircraftID", 0)) in (1,2,3)]
    uav_missions    = [im for im in missions if int(im.get("aircraftID", 0)) in (4,5,6)]

    flight_plans_0303: List[dict] = []
    flight_plans_0304: List[dict] = []

    # 0303 (UAV)
    try:
        wp_alloc_3 = d0303._WPAllocator()
        flight_plans_0303 = d0303.build_flight_plans(uav_missions, wp_alloc_3, MainGUI.CRUISE_SP, turn_step_deg=15.0)
        # pathID 강제 일치
        for fp in flight_plans_0303:
            aid = int(fp.get("aircraftID", 0)); mid = int(fp.get("individualMissionID", 0))
            key = (aid, mid)
            if key in pid_map and str(fp.get("pathID")) != str(pid_map[key]):
                fp["pathID"] = pid_map[key]
    except Exception as e:
        # UAV가 없으면 비어있을 수 있음
        flight_plans_0303 = []

    # 0304 (LAH) - 고정 100 m 분할 버전 사용
    try:
        wp_alloc_4 = d0303._WPAllocator()
        flight_plans_0304 = d0304.build_lah_flight_plans_fixed(manned_missions, cruise_speed=MainGUI.CRUISE_SP, wp_alloc=wp_alloc_4)
        for fp in flight_plans_0304:
            aid = int(fp.get("aircraftID", 0)); mid = int(fp.get("individualMissionID", 0))
            key = (aid, mid)
            if key in pid_map and str(fp.get("pathID")) != str(pid_map[key]):
                fp["pathID"] = pid_map[key]
    except Exception as e:
        flight_plans_0304 = []

    if not flight_plans_0303 and not flight_plans_0304:
        raise RuntimeError("0303/0304 모두 생성 실패")

    # 5) 디스크 저장 (클린 세이브 제어)
    dir_mp  = Path(db_root) / "MissionPlan"
    dir_imp = Path(db_root) / "IndividualMissionPlan"
    dir_fp  = Path(db_root) / "FlightPath"
    for d in (dir_mp, dir_imp, dir_fp):
        d.mkdir(parents=True, exist_ok=True)

    if clean:
        for d in (dir_mp, dir_imp, dir_fp):
            for p in d.glob("*.json"):
                try: p.unlink()
                except Exception: pass

    try:
        mp_id = str(mp_json.get("missionPlanID") or mp_json.get("MissionPlanID"))
    except Exception:
        mp_id = str(int(time.time()))

    # 0301 저장
    (dir_mp / f"{mp_id}.json").write_text(
        json.dumps(mp_json, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # 0302 저장 (missions 사용)
    imp_pkgs = d0302.build_mission_packages(missions, cmpk_id=int(Path(cmpk_path).stem), plan_pkg_map=imp_id_map)
    for pkg in imp_pkgs:
        imp_id = str(pkg.get("individualMissionPackageID") or pkg.get("individualMissionPlanPackageID"))
        (dir_imp / f"{imp_id}.json").write_text(
            json.dumps(pkg, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    # 0303/0304 저장
    def _dump_fps(lst: List[dict]) -> int:
        c = 0
        for fp in lst:
            pid = str(fp["pathID"])
            (dir_fp / f"{pid}.json").write_text(json.dumps(fp, indent=2, ensure_ascii=False), encoding="utf-8"); c += 1
        return c
    _ = _dump_fps(flight_plans_0303) + _dump_fps(flight_plans_0304)

    # 임시 폴더 정리
    try:
        if out_root.exists():
            shutil.rmtree(out_root)
    except Exception:
        pass

    return int(mp_id)

def _save_option_info_0701_multi(mp_ids: List[int], db_root: str, filename: str = "1.json") -> Path:
    """
    0701 MissionPlanOptionInfo 단일 파일 저장 (옵션: 1/4/5)
    - 문자열 optionName 제거, 숫자 optionId만 사용.
    """
    import json, time
    out_dir = Path(db_root) / "MissionPlanOptionInfo"
    out_dir.mkdir(parents=True, exist_ok=True)

    # 2000-01-01 기준 ms
    ts = int(time.time() * 1000) - 946_684_800_000

    EFFECTS = {
        1: ( 0,  0,  0),   # 시스템 추천
        4: (-1, -1,  1),   # 정찰특화
        5: ( 1,  1, -1),   # 최소시간
    }
    code_order = (1, 4, 5)

    option_list = []
    for i, oid in enumerate(code_order):
        if i >= len(mp_ids): break
        sr, tc, reff = EFFECTS[oid]
        option_list.append({
            "optionId": int(oid),               # ★ 숫자 코드만
            "missionPlanId": int(mp_ids[i]),
            "survivalRate": sr,
            "timeContraction": tc,
            "recogEffectiveness": reff,
            "distance": 0,
            "target": 0
        })

    payload = {
        "timestamp": ts,
        "source": "MOB",
        "autoExecution": False,
        "optionList": option_list
    }

    out_path = out_dir / filename
    out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return out_path

def generate_mission_and_options_headless(sets: int = 3, db_root: str | None = None,
                                          cmpk_path: str | None = None, mrpk_path: str | None = None) -> list[int]:
    """
    3세트(기본) 임무를 연속 생성/저장하고, 마지막에 0701(1.json)을 1회 저장.
    - 첫 세트만 clean-save (기존 json 삭제), 이후는 누적 저장
    - 0701은 optionName을 쓰지 않고 optionId(정수)만 기록
    - 반환: 생성된 MissionPlanID 목록
    """
    import os, json, time, shutil
    from pathlib import Path
    from AnS import run_divide_and_pattern, build_mission_plan_0301
    from data_def import d0302, d0303, d0304
    from data_def.id_allocator import next_path_id

    here = Path(__file__).resolve()
    proj = here.parents[2]
    if db_root is None:
        db_root = os.environ.get("KU_MISSION_DB_ROOT") or str(proj / "database")
    DB = Path(db_root)
    DIR_0201 = DB / "InputMissionPlan"
    DIR_0203 = DB / "MissionReferenceInfo"
    DIR_MP   = DB / "MissionPlan"
    DIR_IMP  = DB / "IndividualMissionPlan"
    DIR_FP   = DB / "FlightPath"
    DIR_0701 = DB / "MissionPlanOptionInfo"
    TMP_OUT  = DB / "mission_output"
    for d in (DIR_0201, DIR_0203, DIR_MP, DIR_IMP, DIR_FP, DIR_0701):
        d.mkdir(parents=True, exist_ok=True)

    def _pick_latest(dd: Path) -> Path | None:
        xs = list(dd.glob("*.json"))
        return max(xs, key=lambda p: p.stat().st_mtime) if xs else None

    cmpk = Path(cmpk_path) if cmpk_path else _pick_latest(DIR_0201)
    mrpk = Path(mrpk_path) if mrpk_path else _pick_latest(DIR_0203)
    if not cmpk or not mrpk:
        raise RuntimeError(f"0201/0203 JSON not found under {DB}")

    def _imp_path_id(im: dict) -> int | None:
        for k in ("pathID", "pathId", "individualMissionPathID", "missionPathID"):
            v = im.get(k)
            if v is not None:
                try: return int(v)
                except: pass
        mi = im.get("individualMissionInfo") or im.get("missionInfo")
        if isinstance(mi, dict):
            for k in ("pathID", "pathId"):
                v = mi.get(k)
                if v is not None:
                    try: return int(v)
                    except: pass
        return None

    mp_ids: list[int] = []
    first_clean_done = False

    for _ in range(int(sets)):
        TMP_OUT.mkdir(parents=True, exist_ok=True)
        imp_paths = run_divide_and_pattern(str(cmpk), str(mrpk), str(TMP_OUT), log=lambda *_: None)
        if not imp_paths:
            raise RuntimeError("IMP 생성 실패")

        mp_path = TMP_OUT / f"MissionPlan_{int(time.time()*1000)}.json"
        build_mission_plan_0301(str(cmpk), str(mrpk), imp_paths, str(mp_path))
        mp_json = json.loads(mp_path.read_text(encoding="utf-8"))
        imp_id_map = {a["aircraftID"]: a["individualMissionPackageID"] for a in mp_json.get("aircraftList", [])}

        missions, pid_map = [], {}
        for imp in imp_paths:
            pkg = json.loads(Path(imp).read_text(encoding="utf-8"))
            aid = int(pkg["aircraftID"])
            for im in pkg.get("individualMissionList", []):
                im2 = dict(im); im2["aircraftID"] = aid
                if "individualMissionPlanPackageID" not in im2 and imp_id_map:
                    im2["individualMissionPlanPackageID"] = imp_id_map.get(aid)
                mid = int(im2.get("individualMissionID", 0))
                if aid in (1, 2, 3):
                    pid = int(next_path_id(aid))
                    im2["pathID"] = pid
                    pid_map[(aid, mid)] = pid
                else:
                    ip = _imp_path_id(im2)
                    if ip is not None:
                        im2["pathID"] = int(ip)
                        pid_map[(aid, mid)] = int(ip)
                missions.append(im2)

        fp3 = d0303.build_flight_plans([im for im in missions if int(im.get("aircraftID", 0)) in (4, 5, 6)],
                                       d0303._WPAllocator(), 40.0, turn_step_deg=15.0)
        for fp in fp3:
            key = (int(fp.get("aircraftID", 0)), int(fp.get("individualMissionID", 0)))
            if key in pid_map:
                fp["pathID"] = pid_map[key]

        manned = [im for im in missions if int(im.get("aircraftID", 0)) in (1, 2, 3)]
        if manned:
            fp4 = d0304.build_lah_flight_plans_fixed(manned, cruise_speed=40.0, wp_alloc=d0303._WPAllocator())
            for fp in fp4:
                key = (int(fp.get("aircraftID", 0)), int(fp.get("individualMissionID", 0)))
                if key in pid_map:
                    fp["pathID"] = pid_map[key]
        else:
            fp4 = []

        if not fp3 and not fp4:
            raise RuntimeError("0303/0304 생성 결과 없음")

        for d in (DIR_MP, DIR_IMP, DIR_FP):
            d.mkdir(parents=True, exist_ok=True)
        if not first_clean_done:
            for d in (DIR_MP, DIR_IMP, DIR_FP):
                for p in d.glob("*.json"):
                    try: p.unlink()
                    except: pass

        mp_id = int(mp_json.get("missionPlanID") or mp_json.get("MissionPlanID") or 0)
        (DIR_MP / f"{mp_id}.json").write_text(json.dumps(mp_json, indent=2, ensure_ascii=False), encoding="utf-8")

        imp_pkgs = d0302.build_mission_packages(missions, cmpk_id=int(cmpk.stem), plan_pkg_map=imp_id_map)
        for pkg in imp_pkgs:
            imp_id = int(pkg.get("individualMissionPackageID") or pkg.get("individualMissionPlanPackageID"))
            (DIR_IMP / f"{imp_id}.json").write_text(json.dumps(pkg, indent=2, ensure_ascii=False), encoding="utf-8")

        def _dump(lst):
            for fp in lst:
                (DIR_FP / f"{int(fp['pathID'])}.json").write_text(json.dumps(fp, indent=2, ensure_ascii=False), encoding="utf-8")
        _dump(fp3); _dump(fp4)

        try:
            shutil.rmtree(TMP_OUT)
        except Exception:
            pass

        mp_ids.append(mp_id)
        if not first_clean_done:
            first_clean_done = True

    # === 0701 저장(숫자 코드만) ==========================================
    # 매핑 순서: 1(시스템 추천) → 4(정찰특화) → 5(최소시간)
    EFFECTS = {1: (0, 0, 0), 4: (-1, -1, 1), 5: (1, 1, -1)}
    code_order = (1, 4, 5)

    opt_list = []
    for i, oid in enumerate(code_order):
        if i >= len(mp_ids): break
        sr, tc, reff = EFFECTS[oid]
        opt_list.append({
            "optionId": int(oid),              # ★ optionName 없음
            "missionPlanId": int(mp_ids[i]),
            "survivalRate": sr,
            "timeContraction": tc,
            "recogEffectiveness": reff,
            "distance": 0,
            "target": 0
        })

    ts = int(time.time()*1000) - 946_684_800_000
    payload = {"timestamp": ts, "source": "MOB", "autoExecution": False, "optionList": opt_list}
    DIR_0701.mkdir(parents=True, exist_ok=True)
    (DIR_0701 / "1.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    return mp_ids


if __name__ == "__main__":
    import argparse, os, sys
    p = argparse.ArgumentParser()
    p.add_argument("--headless", action="store_true")
    p.add_argument("--generate-options", action="store_true")
    p.add_argument("--sets", type=int, default=3)
    p.add_argument("--db-root", type=str, default=os.environ.get("KU_MISSION_DB_ROOT", ""))
    args, _ = p.parse_known_args()

    if args.headless and args.generate_options:
        os.environ["KU_HEADLESS"] = "1"
        ids = generate_mission_and_options_headless(sets=args.sets, db_root=args.db_root or None)
        print("GENERATED_MISSION_PLAN_IDS", ",".join(map(str, ids)))
        sys.exit(0 if len(ids) >= int(args.sets) else 2)

    # GUI 경로 (필요 시)
    try:
        main()
    except NameError:
        pass

# ════════════════════════════════════════════════════════════════════
def main():
    import sys, os
    from PyQt5.QtWidgets import QApplication

    if os.name == "nt":
        import multiprocessing
        multiprocessing.freeze_support()

    # 이미 위에서 가드 인스턴스를 만들었으므로, 여기서는 재사용
    app = QApplication.instance() or QApplication(sys.argv)

    win = MainGUI()
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    import argparse, sys, os
    parser = argparse.ArgumentParser()
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--generate-options", action="store_true")
    parser.add_argument("--sets", type=int, default=3)
    parser.add_argument("--db-root", type=str, default=os.environ.get("KU_MISSION_DB_ROOT", ""))
    args, unknown = parser.parse_known_args()

    if args.headless and args.generate_options:
        ids = generate_mission_and_options_headless(sets=args.sets, db_root=args.db_root or None)
        print("GENERATED_MISSION_PLAN_IDS", ",".join(map(str, ids)))
        sys.exit(0)

    # 기존 GUI 실행 경로(있다면) 유지
    try:
        main()  # 파일에 main()이 있다면 GUI 실행
    except NameError:
        pass