"""Additional monitoring GUI tabs."""

