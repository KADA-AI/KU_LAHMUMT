"""Mission planning orchestration helpers."""
