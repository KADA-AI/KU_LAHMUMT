"""MissionPlanner auxiliary tools package."""
