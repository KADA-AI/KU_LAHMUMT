"""Mission-plan delivery helpers."""
