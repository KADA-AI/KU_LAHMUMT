"""Mission-planning test tools."""

