"""Mission generation engine components."""
