"""Mission-planning pipeline implementations."""

